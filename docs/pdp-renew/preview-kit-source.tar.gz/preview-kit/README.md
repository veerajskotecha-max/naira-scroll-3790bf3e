# Product page and bag: the preview kit

One command builds a self-contained folder (`dist/`) that shows today's product
page and bag (**Before**) beside the redesign (**After**), under a slim ribbon
that says `PREVIEW · NOTHING HERE IS LIVE`. The folder is published as a
claude.ai page; it needs no server and asks no outside host for anything.

    ./build.sh [after-source-dir]        # default /tmp/pdp-clean; before is always /tmp/pdp-base
    node check.cjs                       # the limits and the offline walk (build.sh runs it at the end)

Nothing here pushes, deploys or writes to Shopify, Supabase or Meta. The two
worktrees are only read: the Vite config, its plugins and the bootstrap all
live in this folder, and Vite's cache, env folder and output point back here.

## What is in dist/

| Path | What |
|---|---|
| `index.html` | The shell: the ribbon and the frame. Plain HTML, CSS and JS, no build. |
| `before/index.html`, `after/index.html` | The shop app, today's and the redesign's. Both load their code from `assets/`. |
| `assets/` | The shop's hashed code, stylesheet and bundled pictures, one folder for both builds. A file both builds produce identically is there once (today the two builds are the same commit, so everything is). |
| `kit/guard.js` | The network guard, loaded before the app. |
| `kit/fixtures.js` | The recorded Storefront answers, the photograph map, the six handles, the two bag pieces. |
| `kit/thumbs.js` | A small inline copy (220 px) of every catalogue piece's first photographs. |
| `media/` | Shopify photographs, WebP, at most 900 px wide. One folder for both builds. |
| `reels/` | The published reels' films (mp4, as the shop serves them, index moved to the front) and posters. About 8 MB. |
| `fonts/` | Cormorant Garamond and Jost (latin, latin-ext), Velista. |
| `title-b.css` | The Title B override (empty until the redesign fills it). |

## The shell

- **Before / After**: loads `before/` or `after/` in the frame, on the same product.
- **Product**: six pieces, one per state (`products.json`): plain, an adjustable ring
  (five fit sizes), an adjustable ring in two metals, a band in three stones with real
  sizes and pre-order sizes, a set, a bestseller.
- **Title A / B**: After only. Sets `data-pdp-title="a"` or `"b"` on the framed
  page's `<html>`; `title-b.css` is linked after the shop's stylesheet. Write
  Title B's rules there under `html[data-pdp-title="b"]`.
- **Open the bag**: reloads the frame with two pieces in the local bag
  (`naira-shopify-cart` in localStorage, backed by the guard's cart) and opens it.
- **Phone / Laptop** (screens 900 px and wider): a centred 390x844 frame, or the
  full width under the ribbon. On a phone the frame fills the screen and the
  ribbon is 36 px: Before / After, and one Options sheet for the rest.
- The address remembers the state: `?v=after&p=<handle>&t=b&d=phone` (and `&bag=1`).

## How the app runs with no network

**The build** (`vite.preview.config.mjs`, passed to the source's own Vite with `-c`):

- `base: './'` and one JS bundle (`inlineDynamicImports`), so it runs under any path.
- `react-router-dom`'s `BrowserRouter` is replaced by a hash router
  (`shims/router.js`): the document stays `<build>/index.html`, the route is
  `#/jewellery/<handle>`, and every relative address keeps working. The page
  opens on `?p=<handle>`. A move to any route but the six product pages is
  refused before it renders, with the note "Not in this preview". Two things the
  shim does that are easy to lose: the hash history is made with `v5Compat`, so a
  `<Link>` (a push) re-renders the page and not only the address; and a `to` that
  is a link's own `href` as the DOM has it (`#/jewellery/x`, which the shop's bag,
  menu and search hand back to `navigate()` after closing) is read as a route.
- Every page but the product page (`keepPages`) is a stub that renders nothing;
  so is any lazily loaded part under a folder named in `absent` (none today).
- No `.env`: Supabase's address is `https://supabase.preview.invalid`, its key `preview`.
- ASCII output (`esbuild.charset`), so no file can carry U+FFFD.
- `index.html` loses every remote tag (font links, preconnects, the pixel and
  Clarity loaders, noscript) and gains the fixtures and the guard, first.

**The guard** (`guard/guard.js`, a classic script, in place before the app's first module):

- `fetch`: a Storefront product question is answered from the fixtures by the
  hash of its text and variables; one not recorded is answered from the
  catalogue the fixtures hold and listed (`__nairaPreview.misses`) so the build
  can record it. Cart calls (`cartCreate`, `cartLinesAdd`, `cartLinesUpdate`,
  `cartLinesRemove`, the `cart` query, `cartAttributesUpdate`,
  `cartDiscountCodesUpdate`) go to a local cart kept in localStorage: same
  shapes, Shopify's line prices, a sold-out variant adds nothing, a missing
  line or cart gets Shopify's own error text. Supabase reads get an empty
  answer, Supabase writes a refusal (nothing is sent, the shop shows its own
  "could not send"). Anything else gets an empty answer and is logged.
- XHR, beacons, WebSockets, EventSource, remote scripts, styles and frames are refused quietly.
- Photographs: in the fixtures and in the code a Shopify photograph is
  `../media/<its original file name>` (the shop's code matches on file names,
  so they are kept whole). At the tag (`src`, `srcset`, `poster`, link
  preloads, inline backgrounds) the guard turns that into the bundled copy
  `media/<name>.webp`, or the small inline copy, or a plain tile.
- Checkout and Buy now: the cart's `checkoutUrl` is `#/preview-checkout`, which
  the page may not go to: the toast says "Checkout is switched off in this
  preview". Fastrr's script is refused, so its fallback (that address) is what runs.
- Links out (WhatsApp, Instagram, mail, the shop's own domain) stay: "Not in this preview".
- A step back never leaves the preview. The page's own back arrow and every overlay
  that closes "the way back would" call `history.back()`, which in a frame walks the
  whole tab: on a page just opened the tab itself went back, out of the preview. The
  guard numbers every history entry this document makes and refuses a step back past
  the first, with the note. (The browser's own back button is the browser's.)
- Supabase's `reels` table and its `reel-media` function are answered from the
  fixtures: the rows as recorded, and each film and poster as its file in `reels/`.
- Where the host gives the frame no storage, the guard supplies a memory one.

**The discount** is not in the cart's answer: the shop works it out itself
(`src/lib/promo.ts`, `cartPricing.ts`: Buy 2 10%, Buy 3 20%, Buy 4 30%, or a
typed code), so the bag's totals and offer bar are the shop's own arithmetic on
the guard's line prices. The guard's cart also answers a `cost` block with the
same rounding, for a redesign that reads it.

**Lazy sections**

| Section | In the preview |
|---|---|
| Customer reviews | Works, from the review data and thumbnails bundled in the shop's code (Supabase's live reviews are answered empty). Writing a review is refused. |
| Complete the look, More like this, the bag's suggestions, search | Work, from the recorded catalogue; their photographs are bundled. |
| "Just bought" card | Works; it picks pieces at random, so it uses the small inline copies. |
| As featured in | Works (bundled). |
| Shop the reel, the reel in the gallery (the "1 / 8 VIDEO" slide) | Work, from the two published reels bundled in `reels/` (recorded read-only by `scripts/reels.cjs`); Add from a reel goes to the local bag. `"reels": false` in `products.json` leaves them out, and the shop then draws no reel section. |
| Pincode check, delivery dates | Work (they are local arithmetic). |
| Sign in, account, wishlist sync | Not in this preview (the wishlist itself works locally). |

## What build.sh does

1. Builds `before` from `/tmp/pdp-base` and `after` from the directory given,
   into `.work/raw-before` and `.work/raw-after`. A source whose commit and
   uncommitted changes are unchanged since its last build is not built again.
2. Fonts: the Google Fonts stylesheet each source's `index.html` asks for is
   fetched once into `cache/fonts` (a new family or weight is picked up by itself).
   Reels: `scripts/reels.cjs` asks Supabase what a visitor's browser asks (one GET on
   the `reels` table, the `reel-media` signing call, GETs of the films and posters,
   with the publishable key from the source's `.env`) and keeps the answers in
   `cache/reels`. Read only; `--refresh` asks again.
3. Rounds of: fetch what is wanted (`scripts/media.cjs`), put `dist/` together
   (`scripts/assemble.cjs`), walk every piece offline in a real browser at phone
   and laptop size, page and bag and menu and search (`scripts/walk.cjs`), and
   record what the pages still asked for: Storefront questions
   (`scripts/record.cjs`, read-only: it refuses a mutation) and photographs drawn
   large. It stops when a walk wants nothing (two rounds from an empty cache, one after).
4. Prints the file count, the total size and the largest file, then runs `check.cjs`.

The last step of a round that wants nothing puts `dist/` together once more with
only the recorded answers that walk used, so an answer to a question no page
asks any more is not shipped.

Flags: `--offline` (use only what `cache/` holds), `--refresh` (ask Shopify
again for every recorded answer: prices, stock, new photographs), `--no-check`.

`PREVIEW_DIST=<dir> ./build.sh …` writes somewhere other than `dist/`.
`node scripts/assemble.cjs` alone puts `dist/` together again in two seconds
from the last builds and the cache (after editing `title-b.css` or the shell).

`cache/` is the kit's memory: `queries.json` (recorded answers, raw),
`media/` and `thumbs/` (photographs), `wanted-media.json` (photographs the walks
asked for; delete it to start that list afresh), `fonts/`, `reels/`. `.work/` is scratch.
Both can be deleted: `./build.sh` then fetches everything again (about five and a
half minutes from nothing, about two with the cache; tested both ways).

## What check.cjs proves

- At most 511 files, each under 15 MB, 30 MB in all; `index.html` at the root.
- No U+FFFD in any text file.
- Every `src`, `href` and `srcset` in the pages and every `url()` in the styles
  is relative and present; no Shopify photograph address is left anywhere; every
  absolute host still spelled out in the code is on a list with the reason it is
  never requested (a new one fails until it is understood and listed).
- The offline walk, `dist/` served by `python3 -m http.server` on
  `127.0.0.1:4410` with every other host aborted and counted (zero allowed):
  the six pieces in both builds at 390x844 and 360x640 (touch) and 1440x900;
  Add to cart; the bag's totals at 1, 2, 3 and 4 pieces; remove; Checkout and
  Buy now (the note, and the page stays); a link to another of the six (that
  piece's own title must be drawn, and back must return); the page's own back
  arrow on a page just opened (the tab must not leave); a link inside the bag;
  the menu's links and a link elsewhere (the note, the address unchanged); on a
  phone, a reel's film loading from `reels/`; and the shell's ribbon, picker,
  Before / After, Title A / B, Open the bag and Phone / Laptop.
- The walks' browser runs with `navigator.webdriver` false
  (`--disable-blink-features=AutomationControlled`). The shop holds back its later
  gallery photographs, the reels and the delivery dates from an automated browser;
  without the flag the walk checks a page no shopper sees.
- Screenshots: `.work/shots/check-*.png`.

`node scripts/edge-check.cjs` tries three more conditions on purpose: a browser
with no Navigation API (Safari before 26.2; only Chromium is installed here, so
it is Chromium with that API taken away), a frame with no storage, and the
shell opened on a state in its address at 360x640.

## The contract: what the redesign must keep true

1. **Files**: the product page is `src/pages/JewelDetailNext.tsx`, loaded with a
   dynamic `import()` (as `src/pageCode.ts` does); the app's entry is
   `index.html` + `src/main.tsx`; the router is `BrowserRouter` imported from
   `react-router-dom`; the route is `/jewellery/:handle`. (A renamed page: add
   its file name to `keepPages` in `products.json`.)
2. **Storefront**: product data goes through `fetch` to the Storefront GraphQL
   address (`…/api/<version>/graphql.json`). Queries may change freely: the
   build records whatever the pages ask. Keep one root field per cart mutation,
   unaliased (`cartCreate`, `cartLinesAdd`, …), and variables named `cartId`,
   `lines`, `lineIds`, `input`, `discountCodes`/`codes`, `attributes`, `id`.
3. **Checkout** leaves through the cart's `checkoutUrl` (or Fastrr's fallback
   to it), as `CartContext.openCheckout` does. A hard-coded checkout address
   would be stopped by the guard only where the browser lets a page veto a
   move (Chrome and Edge, Safari 26.2 and later).
4. **The bag** is kept in localStorage under `naira-shopify-cart` as
   `{ items, cartId, checkoutUrl }`, each item `{ id (handle), variantId,
   lineId, name, price, priceLabel, currencyCode, image, quantity, size?,
   selectedOptions?, variantTitle? }`. "Open the bag" writes that.
5. **The bag's button**: something matching `button[aria-label^="Open cart"]`
   (today's header), or `button[aria-label^="Open bag"]`, or any element with
   `data-preview-open-bag`. The open bag is a `[role="dialog"][data-state="open"]`.
6. **For check.cjs** (it fails loudly, it does not break the preview): the page
   has an `h1` whose text contains the piece's name as `products.json` labels it;
   a back control (`button[aria-label="Go back"]`, or a button or link reading
   "Back"); the phone menu is `#nav-menu` behind a button whose label contains
   "menu"; buttons whose text is "Add to cart" and "Buy now"; in the bag a link
   to each line's piece (`a[href="#/jewellery/<handle>"]`), a
   button "Checkout", `aria-label="Increase quantity"` and
   `aria-label^="Remove"`; totals written like `₹3,103`.
7. **Title A / B**: style Title B under `html[data-pdp-title="b"]` in
   `title-b.css` (here, then rebuild, or straight in `dist/`). The attribute is
   only ever set on After.
8. **Photographs**: any `cdn.shopify.com` image the pages draw is found by the
   walk and bundled. A photograph set by a path the guard does not watch (a CSS
   file's `url()`, a canvas) would show a plain tile: use an `<img>`, `srcset`,
   or an inline `background-image`.
9. **Reels**: read as today, `supabase.from("reels")` for the rows and
   `supabase.functions.invoke("reel-media")` for `{ urls: { <storage path>: <address> } }`,
   played by a `<video src>`. Any other source is answered empty, and the reel
   section is then simply not there (say so if that happens: `__nairaPreview.log`).
10. **No new remote thing at load**: a new font goes in `index.html` as a
    Google Fonts `<link>` (it is bundled by itself); a new script or API host
    is refused by the guard and must be named in `check.cjs` (`KNOWN`) once understood.

## Things that look odd and are right

- After Checkout or Buy now the bag closes behind the note: the shop closes its bag
  as it hands off (`CartContext.openCheckout`), and here the hand-off is refused.
- "Open the bag" reloads the framed page and replaces whatever the bag held with
  the two pieces in `products.json` (`bag`).
- The bag is one bag for Before and After (same storage), as it would be on the site.
- The laptop page has no "Shop the reel" section: that is the shop's own layout today.
- In a browser's network panel a reel's film may show as cancelled when its slide
  leaves the screen; the browser drops a film it no longer plays.
- The ribbon takes 36 px, so on a 390x844 phone the page has 808 px (360x640: 604).
- Photographs are at most 900 px wide; the full-screen zoom on a laptop is softer
  than on the site.

## Changing the six

Edit `products.json` (`products`: handle, label, state; `bag`: the two pieces
"Open the bag" puts in) and run `./build.sh`. Their galleries are fetched whole.
