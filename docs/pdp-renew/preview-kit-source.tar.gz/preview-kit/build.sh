#!/usr/bin/env bash
# The product page preview, in one command.
#
#   ./build.sh [after-source-dir] [--offline] [--refresh] [--no-check]
#
#   after-source-dir   the redesign's worktree (default /tmp/pdp-clean); before/ is always /tmp/pdp-base
#   --offline          record nothing and download nothing: build from what cache/ already holds
#   --refresh          ask Shopify again for every recorded answer (prices, stock, photographs)
#   --no-check         skip check.cjs at the end
#
# Writes dist/ (index.html, before/, after/, assets/, kit/, media/, reels/, fonts/, title-b.css) and prints
# the file count, the total size and the largest file. Reads the two worktrees; writes only here.
set -euo pipefail
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BEFORE="${PREVIEW_BEFORE_SRC:-/tmp/pdp-base}"
AFTER=""
OFFLINE=0; REFRESH=0; CHECK=1
for arg in "$@"; do
  case "$arg" in
    --offline) OFFLINE=1 ;;
    --refresh) REFRESH=1 ;;
    --no-check) CHECK=0 ;;
    -h|--help) sed -n '2,12p' "${BASH_SOURCE[0]}"; exit 0 ;;
    *) AFTER="$arg" ;;
  esac
done
AFTER="$(cd "${AFTER:-/tmp/pdp-clean}" && pwd)"
BEFORE="$(cd "$BEFORE" && pwd)"
export PREVIEW_KIT="$KIT" PREVIEW_BEFORE_SRC="$BEFORE"
mkdir -p "$KIT/.work" "$KIT/cache"
say() { printf '\n== %s\n' "$*"; }

# A source's state: its commit plus everything not committed. The same state is not built twice.
signature() {
  ( cd "$1" && if git rev-parse --show-toplevel >/dev/null 2>&1 && [ "$(git rev-parse --show-toplevel)" = "$(pwd -P)" ]; then
      git rev-parse HEAD; git status --porcelain; git diff HEAD
      git ls-files --others --exclude-standard | while read -r f; do [ -f "$f" ] && { echo "$f"; cat "$f"; }; done
    else # not a checkout of its own: every source file's name, size and time
      find src index.html package.json tailwind.config.* postcss.config.* -type f -printf '%p %s %T@\n' 2>/dev/null | sort
    fi ; \
    cat "$KIT/vite.preview.config.mjs" "$KIT/products.json" "$KIT"/shims/*.js ) | sha1sum | cut -d' ' -f1
}
build_app() { # name, source dir
  local name="$1" src="$2" out="$KIT/.work/raw-$1" sig
  sig="$(signature "$src")"
  if [ -f "$out/index.html" ] && [ "$(cat "$out/.signature" 2>/dev/null)" = "$sig" ]; then
    echo "$name: unchanged since its last build ($src), reusing it"; return
  fi
  [ -d "$src/node_modules" ] || { echo "$src has no node_modules (run its install first)"; exit 1; }
  echo "$name: building $src"
  ( cd "$src" && PREVIEW_SRC="$src" PREVIEW_OUT="$out" PREVIEW_NAME="$name" \
      node node_modules/vite/bin/vite.js build -c "$KIT/vite.preview.config.mjs" 2>&1 \
      | grep -v -e "CJS build of Vite" -e "didn't resolve at build time" -e '^$' || true )
  [ -f "$out/index.html" ] || { echo "$name: the build wrote no index.html"; exit 1; }
  echo "$sig" > "$out/.signature"
}

say "1/4 the two builds"
build_app before "$BEFORE"
build_app after "$AFTER"

say "2/4 fonts and reels"
node "$KIT/scripts/fonts.cjs" "$BEFORE" "$AFTER" || echo "fonts: kept what the cache holds"

if [ "$OFFLINE" = 0 ]; then
  if [ "$REFRESH" = 1 ]; then node "$KIT/scripts/reels.cjs" "$BEFORE" "$AFTER" --refresh; else node "$KIT/scripts/reels.cjs" "$BEFORE" "$AFTER"; fi
fi

say "3/4 fixtures and photographs (each round: assemble, walk the pages offline, fetch what they still wanted)"
[ "$REFRESH" = 1 ] && [ "$OFFLINE" = 0 ] && node "$KIT/scripts/record.cjs" --refresh
pkill -f "http.server 4410 --bind 127.0.0.1" 2>/dev/null || true
for round in 1 2 3 4 5 6; do
  [ "$OFFLINE" = 0 ] && node "$KIT/scripts/media.cjs" "$KIT/.work/raw-before" "$KIT/.work/raw-after"
  node "$KIT/scripts/assemble.cjs"
  node "$KIT/scripts/walk.cjs" --collect
  want="$(node -e 'const c=require(process.argv[1]);console.log(c.misses+c.fresh)' "$KIT/.work/collect.json")"
  if [ "$want" = 0 ]; then node "$KIT/scripts/assemble.cjs" --prune; break; fi
  if [ "$OFFLINE" = 1 ]; then echo "offline: left as it is (the pages show a plain tile for a photograph the cache lacks)"; break; fi
  [ "$round" = 6 ] && { echo "still wanting after 6 rounds: see .work/collect.json"; break; }
  node "$KIT/scripts/record.cjs" "$KIT/.work/misses.json"
done

say "4/4 the preview"
node -e '
const fs=require("fs"),path=require("path");const D=process.argv[1];
const walk=d=>fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(d,e.name)):[path.join(d,e.name)]);
const files=walk(D).map(f=>[f,fs.statSync(f).size]).sort((a,b)=>b[1]-a[1]);
const total=files.reduce((n,f)=>n+f[1],0);
console.log(`${D}`);
console.log(`files: ${files.length} (limit 511)   total: ${(total/1e6).toFixed(2)} MB (limit 30)   largest: ${path.relative(D,files[0][0])} ${(files[0][1]/1e6).toFixed(2)} MB (limit 15)`);
' "${PREVIEW_DIST:-$KIT/dist}"
if [ "$CHECK" = 1 ]; then
  say "check"
  node "$KIT/check.cjs"
fi
