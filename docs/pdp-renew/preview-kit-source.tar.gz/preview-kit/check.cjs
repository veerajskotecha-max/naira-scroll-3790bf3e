#!/usr/bin/env node
/*
  Proves dist/ is fit to publish as a claude.ai page, and that it works with
  nothing but its own files.

    node check.cjs [--quick]      (--quick: one viewport per build instead of three)

  1. Limits: at most 511 files, each under 15 MB, 30 MB in all, index.html at the root.
  2. No U+FFFD in any .js, .css or .html.
  3. Addresses: every src / href / srcset in the pages and every url() in the
     styles is relative (or data:); every absolute address left in the code is
     named below with why it is never requested. A host not on the list fails.
  4. The offline walk: dist/ served by python3 -m http.server on 127.0.0.1:4410,
     every request to any other host aborted and counted (none may be needed).
     Each of the six pieces, in before/ and after/, at 390x844 and 360x640
     (touch) and 1440x900: the page draws, its photographs are bundled, no
     console error, no Storefront question outside the fixtures. Then the
     flows: Add to cart, the bag's totals and offer, + and remove, Checkout and
     Buy now (the note, and the page stays), a link to another of the six (the
     piece itself is drawn, and back returns), the page's own back arrow on a
     page just opened (it must not walk the tab out of the preview), a link
     inside the bag, the menu's links and a link elsewhere (the note), the
     reels' film, and the shell's switches.
     The browser runs with navigator.webdriver false: the shop holds back its
     later gallery photographs, the reels and the delivery dates from an
     automated browser, and the walk must see what a shopper sees.

  Screenshots land in .work/shots/check-*.png: look at them.
*/
const { fs, path, KIT, DIST, WORK, CONFIG, SIX, readJson, walk } = require("./scripts/lib.cjs");
const { BASE, HOST, WORKERS, serve, guarded, settle, scrollThrough, openPiece, harvest, pool } = require("./scripts/walk.cjs");

const QUICK = process.argv.includes("--quick");
const SHOTS = path.join(WORK, "shots");
const failures = [];
const notes = [];
const fail = (what) => failures.push(what);
const ok = (what) => console.log(`  ok  ${what}`);

/* Hosts that may still be spelled out in the code, and why none of them is ever requested. */
const KNOWN = {
  "www.w3.org": "XML namespaces (SVG, XLink, MathML)",
  "reactjs.org": "React's own error text",
  "react.dev": "React's own error text",
  "reactrouter.com": "React Router's warning text",
  "tanstack.com": "React Query's warning text",
  "github.com": "library warning text",
  "radix-ui.com": "Radix's warning text",
  "gsap.com": "GSAP's licence comment",
  "jcgt.org": "a paper cited in three.js",
  "threejs.org": "three.js's own documentation strings",
  "greensock.com": "GSAP's licence comment",
  "fb.me": "React's old error links",
  "schema.org": "structured data vocabulary (JSON-LD text, never fetched)",
  "nairaflore.com": "the shop's own links and canonical address: a link is kept in the page by the guard",
  "www.nairaflore.com": "the shop's host name, compared against, never fetched",
  "payments.nairaflore.com": "the checkout's host: checkout is switched off (its address here is #/preview-checkout)",
  "nc5eti-gp.myshopify.com": "the Storefront API address: the guard answers it from the fixtures and the local cart",
  "cdn.shopify.com": "tested for by the shop's image helpers; every photograph address is rewritten to media/ at build time and at the sink",
  "supabase.preview.invalid": "the Supabase address the preview is built with (no real one): the guard answers it empty",
  "wa.me": "WhatsApp links: the guard keeps them in the page (Not in this preview)",
  "api.whatsapp.com": "WhatsApp links: the guard keeps them in the page",
  "www.instagram.com": "a link: the guard keeps it in the page",
  "instagram.com": "a link: the guard keeps it in the page",
  "www.facebook.com": "a link: the guard keeps it in the page",
  "fastrr-boost-ui.pickrr.com": "Fastrr's checkout script and style: refused at the sink by the guard",
  "www.google.com": "a maps or search link: the guard keeps it in the page",
  "maps.google.com": "a link: the guard keeps it in the page",
  "shiprocket.co": "a tracking link: the guard keeps it in the page",
  "www.shiprocket.in": "a tracking link: the guard keeps it in the page",
  "localhost": "library defaults, never requested",
  "example.com": "library documentation strings",
  "lovable.dev": "a link: the guard keeps it in the page",
  "www.timesofindia.com": "a press link: the guard keeps it in the page",
  "fonts.googleapis.com": "named by main.tsx's font switch only; the stylesheet tag itself is removed and the fonts are bundled",
};

/* ---------- 1 to 3: the files ---------- */
const staticChecks = () => {
  console.log("\nfiles");
  if (!fs.existsSync(path.join(DIST, "index.html"))) return void fail("dist/index.html is missing: run build.sh");
  const files = walk(DIST);
  const sizes = files.map((f) => [f, fs.statSync(f).size]).sort((a, b) => b[1] - a[1]);
  const total = sizes.reduce((n, f) => n + f[1], 0);
  files.length <= 511 ? ok(`${files.length} files (limit 511)`) : fail(`${files.length} files: over the 511 limit`);
  sizes[0][1] < 15e6 ? ok(`largest file ${path.relative(DIST, sizes[0][0])}, ${(sizes[0][1] / 1e6).toFixed(2)} MB (limit 15)`) : fail(`${path.relative(DIST, sizes[0][0])} is ${(sizes[0][1] / 1e6).toFixed(2)} MB: over 15 MB`);
  total <= 30e6 ? ok(`${(total / 1e6).toFixed(2)} MB in all (limit 30)`) : fail(`${(total / 1e6).toFixed(2)} MB in all: over 30 MB`);
  for (const need of ["before/index.html", "after/index.html", "kit/guard.js", "kit/fixtures.js", "fonts/fonts.css", "title-b.css", "media/_missing.svg"]) if (!fs.existsSync(path.join(DIST, need))) fail(`dist/${need} is missing`);

  const texts = files.filter((f) => /\.(js|css|html|svg|json)$/.test(f));
  const bad = texts.filter((f) => fs.readFileSync(f, "utf8").includes("�"));
  bad.length ? fail(`U+FFFD in ${bad.map((f) => path.relative(DIST, f)).join(", ")}`) : ok(`no U+FFFD in ${texts.length} text files`);
  const odd = files.filter((f) => !/\.(html|js|css|webp|jpg|jpeg|png|svg|gif|woff2|ttf|json|avif|mp4|webm|ico)$/i.test(f));
  odd.length ? fail(`files of a type a page may not serve: ${odd.map((f) => path.relative(DIST, f)).join(", ")}`) : ok("every file is a web type");

  // pages: every address in an attribute is relative
  const absolute = (v) => /^(?:[a-z][a-z0-9+.-]*:)?\/\//i.test(v) || v.startsWith("/");
  let attrs = 0;
  for (const f of files.filter((x) => x.endsWith(".html"))) {
    const html = fs.readFileSync(f, "utf8").replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, (s) => s.match(/^<script\b[^>]*>/i)[0] + "</script>");
    for (const m of html.matchAll(/\b(src|href|srcset|poster|action|data)=["']([^"']*)["']/gi)) {
      attrs += 1;
      for (const part of m[1].toLowerCase() === "srcset" ? m[2].split(",").map((p) => p.trim().split(/\s+/)[0]) : [m[2]]) {
        if (part && !/^(data:|#|about:)/.test(part) && absolute(part)) fail(`${path.relative(DIST, f)}: ${m[1]}="${part.slice(0, 80)}" is not relative`);
      }
    }
  }
  ok(`${attrs} addresses in the pages' tags, all relative`);
  // styles: every url() relative, and it exists
  let urls = 0;
  for (const f of files.filter((x) => x.endsWith(".css"))) {
    for (const m of fs.readFileSync(f, "utf8").matchAll(/url\(\s*(["']?)([^"')]+)\1\s*\)/g)) {
      const u = m[2].trim();
      if (/^(data:|#)/.test(u)) continue;
      urls += 1;
      if (absolute(u) || /^[a-z][a-z0-9+.-]*:/i.test(u)) fail(`${path.relative(DIST, f)}: url(${u.slice(0, 80)}) is not relative`);
      else if (!fs.existsSync(path.resolve(path.dirname(f), u.split(/[?#]/)[0]))) fail(`${path.relative(DIST, f)}: url(${u.slice(0, 80)}) names a file that is not in dist`);
    }
  }
  ok(`${urls} url() in the styles, all relative and present`);
  // code: every absolute host is known
  const hosts = new Map();
  const inFixtures = new Map();
  for (const f of files.filter((x) => /\.(js|html|css)$/.test(x))) {
    const target = path.relative(DIST, f) === path.join("kit", "fixtures.js") ? inFixtures : hosts;
    for (const m of fs.readFileSync(f, "utf8").matchAll(/(?:https?|wss?):\/\/([a-zA-Z0-9.-]*[a-zA-Z0-9])/g)) if (!target.has(m[1])) target.set(m[1], path.relative(DIST, f));
  }
  const unknown = [...hosts].filter(([h]) => !KNOWN[h]);
  unknown.length
    ? fail(`absolute addresses on hosts the check does not know (name each in check.cjs KNOWN once it is understood): ${unknown.map(([h, f]) => `${h} (${f})`).join(", ")}`)
    : ok(`${hosts.size} hosts spelled out in the code, each known and never requested: ${[...hosts.keys()].join(", ")}`);
  if (inFixtures.size) notes.push(`inside the fixtures (text the page may show, never fetched): ${[...inFixtures.keys()].join(", ")}`);
  const cdnLeft = files.filter((x) => /\.(js|html|css)$/.test(x)).filter((f) => /cdn\.shopify\.com\/[^"'`\s)]*\.(?:jpe?g|png|webp|gif)/i.test(fs.readFileSync(f, "utf8")));
  cdnLeft.length ? fail(`Shopify photograph addresses left in ${cdnLeft.map((f) => path.relative(DIST, f)).join(", ")}`) : ok("no Shopify photograph address is left in the code or the fixtures");
  const media = files.filter((f) => /[\\/]media[\\/].+\.webp$/.test(f));
  ok(`${media.length} photographs in media/`);
};

/* ---------- 4: the offline walk ---------- */
const inr = (n) => `₹${Math.round(n).toLocaleString("en-IN")}`;
const text = (page, sel) => page.locator(sel).first().innerText({ timeout: 3000 }).catch(() => "");
const bagSel = '[role="dialog"][data-state="open"]';
const toastSel = "[data-naira-preview-toast]";
const toastSays = async (page, words) => {
  await page.waitForFunction(([sel, w]) => (document.querySelector(sel)?.textContent || "").includes(w) && getComputedStyle(document.querySelector(sel)).opacity !== "0", [toastSel, words], { timeout: 5000 });
};

const pageCheck = async (browser, build, view, handle, sink, shots) => {
  const tag = `${build} ${view} ${handle}`;
  const mine = { outside: [], errors: [] };
  const { context, page } = await guarded(browser, view, mine);
  try {
    await openPiece(page, build, handle);
    const product = CONFIG.products.find((p) => p.handle === handle);
    const h1 = (await text(page, "#root h1")).trim();
    if (!h1) fail(`${tag}: no title on the page`);
    else if (product && h1.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "") !== product.label.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")) notes.push(`${tag}: the title reads "${h1}" (the picker says "${product.label}")`);
    if (shots) await page.screenshot({ path: path.join(SHOTS, `check-${build}-${view}-${handle}.png`) });
    await scrollThrough(page);
    await settle(page, 300);
    const state = await page.evaluate(async () => {
      const imgs = [...document.querySelectorAll("img")].filter((i) => i.getClientRects().length);
      await Promise.all(imgs.filter((i) => !i.complete && i.loading !== "lazy").map((i) => new Promise((r) => { i.addEventListener("load", r, { once: true }); i.addEventListener("error", r, { once: true }); setTimeout(r, 2500); })));
      const src = (i) => i.currentSrc || i.src || "";
      return {
        missing: imgs.filter((i) => src(i).includes("_missing.svg")).map((i) => src(i).split("#")[1] || i.alt).slice(0, 5),
        broken: imgs.filter((i) => i.complete && i.naturalWidth === 0 && src(i) && !src(i).startsWith("data:")).map((i) => src(i).slice(-70)).slice(0, 5),
        bundled: imgs.filter((i) => /\/media\/[^_]/.test(src(i)) && i.naturalWidth > 0).length,
        remote: imgs.filter((i) => /^https?:/.test(src(i)) && !src(i).startsWith(location.origin)).map((i) => src(i).slice(0, 80)),
        overflow: document.documentElement.scrollWidth - document.documentElement.clientWidth,
      };
    });
    const h = await harvest(page);
    if (state.bundled < 2) fail(`${tag}: only ${state.bundled} bundled photographs drew`);
    if (state.missing.length) fail(`${tag}: photographs shown that are not bundled: ${state.missing.join(", ")}`);
    if (state.broken.length) fail(`${tag}: pictures that did not load: ${state.broken.join(", ")}`);
    if (state.remote.length) fail(`${tag}: pictures still on a remote address: ${state.remote.join(", ")}`);
    if (state.overflow > 1) notes.push(`${tag}: the page is ${state.overflow}px wider than the screen`);
    if (h.misses.length) fail(`${tag}: ${h.misses.length} Storefront questions the fixtures do not hold (run build.sh online)`);
    sink.pages += 1;
  } catch (e) {
    fail(`${tag}: ${String(e).split("\n")[0].slice(0, 200)}`);
  } finally {
    for (const o of mine.outside) sink.outside.push(`${tag}: ${o}`);
    for (const e of new Set(mine.errors)) fail(`${tag}: ${e}`);
    await context.close();
  }
};

const flowCheck = async (browser, build, view, sink) => {
  const tag = `${build} ${view} flows`;
  const mine = { outside: [], errors: [] };
  const { context, page } = await guarded(browser, view, mine);
  const fx = readFixtures();
  const price = (handle) => fx.priceOf(handle);
  const step = async (name, run) => {
    try {
      await run();
      sink.steps += 1;
    } catch (e) {
      fail(`${tag}: ${name}: ${String(e).split("\n")[0].slice(0, 220)}`);
      await page.screenshot({ path: path.join(SHOTS, `check-FAILED-${build}-${view}-${name.replace(/\W+/g, "-")}.png`) }).catch(() => {});
    }
  };
  const bagText = () => page.locator(bagSel).first().innerText({ timeout: 3000 });
  const expectBag = async (words, why) => {
    await page.waitForFunction(([sel, w]) => (document.querySelector(sel)?.innerText || "").replace(/\s+/g, " ").includes(w), [bagSel, words], { timeout: 6000 }).catch(async () => {
      throw new Error(`${why}: the bag does not say "${words}" (it says: ${(await bagText().catch(() => "nothing")).replace(/\s+/g, " ").slice(0, 160)})`);
    });
  };
  try {
    const a = "woven-gold-hoops", b = "prism-riviere-bracelet";
    const pa = price(a), pb = price(b);

    await step("add to cart", async () => {
      await openPiece(page, build, a, "&bag=0");
      // today's page says "Add to cart"; the renewed one "Add to bag"
      const add = page.locator('#root button:has-text("Add to cart"), #root button:has-text("Add to bag")').first();
      await add.scrollIntoViewIfNeeded();
      await add.click();
      await page.waitForSelector(bagSel, { timeout: 15000 });
      await expectBag(inr(pa), "one piece added");
      await page.screenshot({ path: path.join(SHOTS, `check-${build}-${view}-bag-1.png`) });
    });
    await step("the bag with two pieces (Open the bag)", async () => {
      await openPiece(page, build, a, "&bag=1");
      await page.waitForSelector(bagSel, { timeout: 15000 });
      await expectBag(inr(Math.round((pa + pb) * 0.9)), "two pieces take 10% (Buy 2)");
      await page.screenshot({ path: path.join(SHOTS, `check-${build}-${view}-bag-2.png`) });
    });
    await step("a third piece takes 20%", async () => {
      await page.locator(`${bagSel} button[aria-label="Increase quantity"], ${bagSel} button[aria-label^="Add one more"]`).first().click();
      await expectBag(inr(Math.round((2 * pa + pb) * 0.8)), "three pieces take 20% (Buy 3)");
    });
    await step("a fourth piece takes 30%", async () => {
      await page.locator(`${bagSel} button[aria-label="Increase quantity"], ${bagSel} button[aria-label^="Add one more"]`).first().click();
      await expectBag(inr(Math.round((3 * pa + pb) * 0.7)), "four pieces take 30% (Buy 4)");
      await page.screenshot({ path: path.join(SHOTS, `check-${build}-${view}-bag-4.png`) });
    });
    await step("checkout stays here", async () => {
      const before = page.url();
      await page.locator(`${bagSel} button:has-text("Checkout")`).last().click();
      await toastSays(page, "Checkout is switched off in this preview");
      await page.waitForTimeout(700);
      await page.screenshot({ path: path.join(SHOTS, `check-${build}-${view}-checkout.png`) });
      await page.waitForTimeout(300);
      if (page.url().split("#")[0] !== before.split("#")[0]) throw new Error(`the page left for ${page.url()}`);
      if (!(await page.locator("#root h1").count())) throw new Error("the product page is gone after Checkout");
    });
    await step("remove a line", async () => {
      await openPiece(page, build, a, "&bag=1");
      await page.waitForSelector(bagSel, { timeout: 15000 });
      await page.locator(`${bagSel} button[aria-label^="Remove"]`).last().click();
      await expectBag(inr(pa), "one piece left at full price");
    });
    await step("buy now stays here", async () => {
      await openPiece(page, build, b, "&bag=0");
      const buy = page.locator('#root button:has-text("Buy now")').first();
      await buy.scrollIntoViewIfNeeded();
      await buy.click();
      await toastSays(page, "Checkout is switched off in this preview");
      await page.waitForTimeout(900);
      if (!(await page.locator("#root h1").count())) throw new Error("the product page is gone after Buy now");
    });
    const titleOf = (handle) => (CONFIG.products.find((x) => x.handle === handle)?.label || handle).toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    const showsPiece = (handle) =>
      page.waitForFunction(
        ([h, want]) => location.hash.indexOf("#/jewellery/" + h) === 0 && (document.querySelector("#root h1")?.innerText || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").includes(want),
        [handle, titleOf(handle)],
        { timeout: 6000 },
      );
    await step("a link to another of the six draws that piece", async () => {
      // The address alone is no proof: a router that is not told of a push changes the address and keeps the old page.
      let from = null, link = null;
      for (const start of SIX) {
        await openPiece(page, build, start, "&bag=0");
        await scrollThrough(page);
        const found = page.locator(SIX.filter((h) => h !== start).map((h) => `#root main a[href="#/jewellery/${h}"], #root main a[href^="#/jewellery/${h}?"]`).join(", ")).locator("visible=true").first(); // a link a shopper can see: the reel section is not drawn on a laptop
        if (await found.count()) { from = start; link = found; break; }
      }
      if (!link) throw new Error("none of the six links to another of the six today: put two related pieces in products.json");
      const target = (await link.getAttribute("href")).replace(/^#\/jewellery\//, "").split("?")[0];
      await link.scrollIntoViewIfNeeded();
      await link.click();
      await showsPiece(target).catch(() => { throw new Error(`the link from ${from} to ${target} did not draw ${target}`); });
      const st = await page.evaluate(() => ({ misses: window.__nairaPreview.misses.length, y: window.scrollY }));
      if (st.misses) throw new Error("the linked page asked the Storefront something outside the fixtures");
      await page.evaluate(() => history.back());
      await showsPiece(from).catch(() => { throw new Error(`back from ${target} did not return to ${from}`); });
    });
    await step("the page's own back arrow on a page just opened stays in the preview", async () => {
      // history.back() in a frame walks the whole tab: with nothing of ours behind, the tab itself would leave.
      await page.goto(`${BASE}/fonts/fonts.css`);
      await openPiece(page, build, a, "&bag=0");
      const back = page.locator('#root main button[aria-label="Go back"], #root main button:has-text("Back"), #root main a:has-text("Back")').locator("visible=true").first();
      // The clean page has no back arrow on a phone (its category link is the way back): there the guard is proven by stepping back in code, which is what the arrow's handler did.
      if (await back.count()) await back.click();
      else await page.evaluate(() => history.back());
      await toastSays(page, "Not in this preview");
      await page.waitForTimeout(500);
      if (!new RegExp(`/${build}/index\\.html`).test(page.url())) throw new Error(`the tab left for ${page.url()}`);
      if (!(await page.locator("#root h1").count())) throw new Error("the product page is gone");
    });
    await step("a link inside the bag moves to that piece", async () => {
      await openPiece(page, build, SIX[1], "&bag=1");
      await page.waitForSelector(bagSel, { timeout: 15000 });
      const link = page.locator(`${bagSel} a[href="#/jewellery/${b}"]`).last();
      if (!(await link.count())) throw new Error(`the bag has no link to ${b}`);
      await link.click();
      await showsPiece(b).catch(() => { throw new Error(`the bag's link did not draw ${b}`); });
    });
    await step("the menu's links say so and stay", async () => {
      await openPiece(page, build, a, "&bag=0");
      const before = await page.evaluate(() => location.hash);
      const burger = page.locator('#root button[aria-label*="menu" i]').locator("visible=true").first();
      if (await burger.count()) { await burger.click(); await page.waitForTimeout(600); }
      const link = page.locator('#nav-menu a[href="#/jewellery"], #root nav a[href="#/jewellery"]').locator("visible=true").first();
      if (!(await link.count())) throw new Error("no menu link to the jewellery page was found");
      await link.click();
      await toastSays(page, "Not in this preview");
      await page.waitForTimeout(400);
      const after = await page.evaluate(() => location.hash);
      if (after !== before) throw new Error(`the address became ${after}`);
    });
    // On a phone: today's laptop page draws no reel section (the shop's own layout).
    if (fx.reels && view !== "laptop") {
      await step("the reels play from the bundle", async () => {
        const handle = fx.reels.rows.flatMap((r) => (r.reel_products || []).map((x) => x.handle)).find((h) => SIX.includes(h));
        if (!handle) return; // no reel shows one of the six: nothing to draw
        await openPiece(page, build, handle, "&bag=0");
        // The film's tag is only on the page while its section is near the screen: walk down until it is.
        let seen = false;
        for (let i = 0; i < 60 && !seen; i++) {
          seen = await page.evaluate(() => [...document.querySelectorAll("#root video")].some((v) => /\/reels\/[^/]+$/.test(v.currentSrc || v.src || "")));
          if (seen) break;
          const end = await page.evaluate(() => (window.scrollBy(0, Math.round(window.innerHeight * 0.5)), window.scrollY + window.innerHeight >= document.documentElement.scrollHeight - 4));
          await page.waitForTimeout(350);
          if (end && i > 2) { seen = await page.evaluate(() => [...document.querySelectorAll("#root video")].some((v) => /\/reels\/[^/]+$/.test(v.currentSrc || v.src || ""))); break; }
        }
        if (!seen) throw new Error("no reel film from dist/reels came onto the page");
        const film = await page.evaluate(async () => {
          const v = [...document.querySelectorAll("#root video")].find((x) => /\/reels\/[^/]+$/.test(x.currentSrc || x.src || ""));
          v.scrollIntoView({ block: "center" });
          v.preload = "auto";
          for (let i = 0; i < 40 && v.readyState < 2 && !v.error; i++) await new Promise((r) => setTimeout(r, 150));
          return { ready: v.readyState, error: v.error ? v.error.code : 0, width: v.videoWidth, src: (v.currentSrc || v.src).split("/").slice(-2).join("/") };
        });
        if (film.error || film.ready < 1 || !film.width) throw new Error(`the film did not load: ${JSON.stringify(film)}`);
        await page.screenshot({ path: path.join(SHOTS, `check-${build}-${view}-reel.png`) });
      });
    }
    await step("a link elsewhere says so and stays", async () => {
      await openPiece(page, build, a, "&bag=0");
      const before = await page.evaluate(() => location.hash);
      const link = page.locator('#root a[href="#/jewellery"], #root a[href="#/"], #root a[href^="#/jewellery/collections"], #root a[href="#/contact"]').first();
      if (!(await link.count())) throw new Error("no link out of the six was found to try");
      await link.evaluate((el) => el.click());
      await toastSays(page, "Not in this preview");
      if ((await page.evaluate(() => location.hash)) !== before) throw new Error("the route changed");
    });
  } finally {
    for (const o of mine.outside) sink.outside.push(`${tag}: ${o}`);
    for (const e of new Set(mine.errors)) fail(`${tag}: ${e}`);
    await context.close();
  }
};

const shellCheck = async (browser, view, sink) => {
  const tag = `shell ${view}`;
  const mine = { outside: [], errors: [] };
  const { context, page } = await guarded(browser, view, mine);
  const frame = () => page.frameLocator("#frame");
  const inFrame = (fn, arg) => page.frames().find((f) => f !== page.mainFrame()).evaluate(fn, arg);
  const step = async (name, run) => {
    try {
      await run();
      sink.steps += 1;
    } catch (e) {
      fail(`${tag}: ${name}: ${String(e).split("\n")[0].slice(0, 220)}`);
      await page.screenshot({ path: path.join(SHOTS, `check-FAILED-shell-${view}-${name.replace(/\W+/g, "-")}.png`) }).catch(() => {});
    }
  };
  const phone = view !== "laptop";
  const tap = async (sel) => {
    if (phone && !(await page.locator(`.ribbon ${sel}`).first().isVisible().catch(() => false))) {
      if (!(await page.locator("#sheet").isVisible())) await page.click("#options");
      await page.locator(`#sheet ${sel}`).first().click();
    } else await page.locator(`.ribbon ${sel}`).first().click();
  };
  try {
    await step("the ribbon", async () => {
      await page.goto(`${BASE}/index.html`);
      await frame().locator("#root h1").first().waitFor({ timeout: 15000 });
      const r = await page.evaluate(() => {
        const rb = document.querySelector(".ribbon").getBoundingClientRect();
        const cs = getComputedStyle(document.querySelector(".ribbon"));
        const fr = document.querySelector("#frame").getBoundingClientRect();
        return { h: rb.height, bg: cs.backgroundColor, color: getComputedStyle(document.querySelector(".mark span:last-child")).color, font: cs.fontFamily, text: document.querySelector(".mark").innerText.replace(/\s+/g, " "), top: fr.top, fw: fr.width, fh: fr.height, vw: innerWidth, vh: innerHeight, sw: document.documentElement.scrollWidth };
      });
      if (!/PREVIEW.*NOTHING HERE IS LIVE/i.test(r.text)) throw new Error(`the ribbon reads "${r.text}"`);
      if (r.h > (phone ? 37 : 41)) throw new Error(`the ribbon is ${r.h}px tall`);
      if (r.bg !== "rgb(26, 22, 20)" || r.color !== "rgb(251, 243, 236)") throw new Error(`ribbon colours are ${r.bg} / ${r.color}`);
      if (!/Jost/.test(r.font)) throw new Error(`ribbon font is ${r.font}`);
      if (r.sw > r.vw) throw new Error(`the shell is ${r.sw}px wide on a ${r.vw}px screen`);
      if (phone && (Math.abs(r.fw - r.vw) > 1 || Math.abs(r.top + r.fh - r.vh) > 1)) throw new Error(`the frame is ${r.fw}x${r.fh} at ${r.top} on a ${r.vw}x${r.vh} screen`);
      if (!(await page.evaluate(() => document.fonts.check('500 10px Jost')))) throw new Error("Jost did not load");
      await page.screenshot({ path: path.join(SHOTS, `check-shell-${view}.png`) });
    });
    await step("Title A / B shows on After only, and reaches the page", async () => {
      const titleIs = (v) => page.waitForFunction((want) => { try { return document.querySelector("#frame").contentDocument.documentElement.getAttribute("data-pdp-title") === want; } catch (e) { return false; } }, v, { timeout: 4000 });
      if ((await inFrame(() => document.documentElement.getAttribute("data-pdp-title"))) !== "a") throw new Error("After does not open on Title A");
      await tap('[data-title="b"]');
      await titleIs("b").catch(() => { throw new Error("data-pdp-title did not become b after choosing Title B"); });
      const sheet = await inFrame(() => !!document.querySelector('link[data-naira-preview-title][href$="title-b.css"]'));
      if (!sheet) throw new Error("title-b.css is not linked in the framed page");
      await tap('[data-title="a"]');
      await titleIs("a").catch(() => { throw new Error("Title A did not come back"); });
      if (phone) await page.keyboard.press("Escape");
    });
    await step("the product picker", async () => {
      const handle = SIX[1];
      if (phone) await tap(`[data-handle="${handle}"]`);
      else await page.selectOption("#piece", handle);
      await page.waitForFunction((h) => document.querySelector("#frame").contentWindow.location.hash.includes(h), handle, { timeout: 8000 });
      await frame().locator("#root h1").first().waitFor({ timeout: 10000 });
      if (phone) {
        await page.click("#options");
        await page.waitForTimeout(250);
        await page.screenshot({ path: path.join(SHOTS, `check-shell-${view}-options.png`) });
        await page.keyboard.press("Escape");
      }
    });
    await step("Before / After", async () => {
      await page.locator('.ribbon [data-build="before"]').click();
      await page.waitForFunction(() => /\/before\/index\.html/.test(document.querySelector("#frame").contentWindow.location.pathname), null, { timeout: 8000 });
      await frame().locator("#root h1").first().waitFor({ timeout: 10000 });
      const hidden = await page.evaluate(() => document.querySelector("#title-wide").hidden && document.querySelector("#title-sheet").hidden);
      if (!hidden) throw new Error("the Title switch shows on Before");
      if ((await inFrame(() => document.documentElement.getAttribute("data-pdp-title"))) !== null) throw new Error("data-pdp-title is set on Before");
      await page.locator('.ribbon [data-build="after"]').click();
      await page.waitForFunction(() => /\/after\/index\.html/.test(document.querySelector("#frame").contentWindow.location.pathname), null, { timeout: 8000 });
      await frame().locator("#root h1").first().waitFor({ timeout: 10000 });
    });
    await step("Open the bag", async () => {
      await tap("[data-bag]");
      await frame().locator(bagSel).first().waitFor({ timeout: 12000 });
      const said = (await frame().locator(bagSel).first().innerText()).replace(/\s+/g, " ");
      const fx = readFixtures();
      const want = inr(Math.round(fx.bag.reduce((n, i) => n + i.price, 0) * 0.9));
      if (!said.includes(want)) throw new Error(`the bag does not total ${want}: ${said.slice(0, 140)}`);
      await page.waitForTimeout(500);
      await page.screenshot({ path: path.join(SHOTS, `check-shell-${view}-bag.png`) });
    });
    if (!phone) {
      await step("Phone / Laptop", async () => {
        await page.locator('.ribbon [data-device="phone"]').click();
        await page.waitForTimeout(300);
        const box = await page.evaluate(() => { const f = document.querySelector("#frame"); return { w: f.clientWidth, h: f.clientHeight, x: f.getBoundingClientRect().left + f.getBoundingClientRect().width / 2, vw: innerWidth }; });
        if (box.w !== 390 || box.h !== 844) throw new Error(`the phone frame is ${box.w}x${box.h}`);
        if (Math.abs(box.x - box.vw / 2) > 2) throw new Error("the phone frame is not centred");
        await page.screenshot({ path: path.join(SHOTS, `check-shell-${view}-as-phone.png`) });
        await page.locator('.ribbon [data-device="laptop"]').click();
        await page.waitForTimeout(200);
        const wide = await page.evaluate(() => document.querySelector("#frame").clientWidth === innerWidth);
        if (!wide) throw new Error("the laptop frame is not the full width");
      });
    }
  } finally {
    for (const o of mine.outside) sink.outside.push(`${tag}: ${o}`);
    for (const e of new Set(mine.errors)) fail(`${tag}: ${e}`);
    await context.close();
  }
};

let fixtureCache = null;
const readFixtures = () => {
  if (fixtureCache) return fixtureCache;
  const js = fs.readFileSync(path.join(DIST, "kit/fixtures.js"), "utf8");
  const data = JSON.parse(js.slice(js.indexOf("=") + 1).replace(/;\s*$/, ""));
  const { productsIn } = require("./scripts/lib.cjs");
  const products = productsIn(data.queries);
  const priceOf = (handle) => {
    const variants = products.get(handle)?.variants?.edges?.map((e) => e.node) ?? [];
    const v = variants.find((x) => x.availableForSale) ?? variants[0];
    if (!v) throw new Error(`the fixtures hold no price for ${handle}`);
    return Number(v.price.amount);
  };
  return (fixtureCache = { ...data, priceOf });
};

const main = async () => {
  fs.mkdirSync(SHOTS, { recursive: true });
  for (const f of fs.readdirSync(SHOTS)) if (f.startsWith("check-")) fs.rmSync(path.join(SHOTS, f));
  staticChecks();
  if (failures.length && !fs.existsSync(path.join(DIST, "index.html"))) return finish();

  console.log("\noffline walk (127.0.0.1:4410, every other host aborted)");
  const { chromium } = require("playwright");
  const server = await serve();
  const browser = await chromium.launch({ args: ["--disable-blink-features=AutomationControlled"] }) /* navigator.webdriver false: the shop holds back its later gallery photographs, reels and delivery dates from an automated browser, and the walk must see what a shopper sees */;
  const sink = { outside: [], pages: 0, steps: 0 };
  try {
    const views = QUICK ? ["phone"] : ["phone", "small", "laptop"];
    const jobs = [];
    for (const build of ["before", "after"]) for (const view of views) for (const handle of SIX) jobs.push(() => pageCheck(browser, build, view, handle, sink, view !== "small" || handle === SIX[0]));
    for (const build of ["before", "after"]) for (const view of QUICK ? ["phone"] : ["phone", "laptop"]) jobs.push(() => flowCheck(browser, build, view, sink));
    for (const view of QUICK ? ["phone"] : ["phone", "small", "laptop"]) jobs.push(() => shellCheck(browser, view, sink));
    await pool(jobs, WORKERS);
  } finally {
    await browser.close();
    server.stop();
  }
  ok(`${sink.pages} product pages drew with their photographs bundled`);
  ok(`${sink.steps} flow steps passed (bag, totals, checkout note, links, the shell's switches)`);
  sink.outside.length ? fail(`${sink.outside.length} requests to an outside host were attempted: ${[...new Set(sink.outside)].slice(0, 6).join(" | ")}`) : ok("0 requests to any outside host");
  finish();
};

const finish = () => {
  if (notes.length) {
    console.log("\nnotes");
    for (const n of [...new Set(notes)]) console.log(`  -  ${n}`);
  }
  if (failures.length) {
    console.log(`\nFAILED (${failures.length})`);
    for (const f of [...new Set(failures)]) console.log(`  x  ${f}`);
    process.exit(1);
  }
  console.log(`\nPASSED. Screenshots: ${SHOTS}/check-*.png`);
};

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
