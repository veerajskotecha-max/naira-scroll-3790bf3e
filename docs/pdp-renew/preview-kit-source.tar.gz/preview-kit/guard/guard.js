/*
  The preview's guard. A classic script, first in each build's index.html, so
  it is in place before the shop's first module runs.

  - fetch and XHR never leave: Storefront product questions are answered from
    the fixtures (dist/kit/fixtures.js), cart calls by a small local cart,
    Supabase with nothing, everything else with an empty answer.
  - Shopify photographs are their bundled copies (dist/media), src and srcset.
  - Remote scripts, styles, frames, sockets and beacons are refused quietly.
  - Checkout and Buy now stay here: "Checkout is switched off in this preview".
  - A link out of the preview says "Not in this preview" and stays.
  - It talks to the shell (dist/index.html) by postMessage: the route it is on,
    Title A / B, and it seeds and opens the bag when asked (?bag=1).
*/
(function () {
  "use strict";
  var W = window;
  var FX = W.__NAIRA_PREVIEW_FIXTURES__ || {};
  var QUERIES = FX.queries || {};
  var MEDIA = FX.media || {};
  var SIX = FX.six || [];
  var REELS = FX.reels && FX.reels.rows && FX.reels.rows.length ? FX.reels : null;
  var BUILD = W.__NAIRA_PREVIEW_BUILD__ || (/\/after\//.test(location.pathname) ? "after" : "before");
  var MEDIA_BASE = "../media/";
  var MISSING = MEDIA_BASE + "_missing.svg";
  var CHECKOUT = "#/preview-checkout";
  var MSG = "naira-preview";
  var params = new URLSearchParams(location.search);

  var log = [];
  var misses = [];
  var hits = {};
  var missingMedia = {};
  var note = function (what, detail) {
    log.push({ what: what, detail: detail === undefined ? "" : String(detail).slice(0, 300) });
    if (log.length > 400) log.shift();
  };

  /* ---------- storage: the real one, or a memory one where the host gives none ---------- */
  var memoryStorage = function () {
    var data = {};
    return {
      getItem: function (k) {
        return Object.prototype.hasOwnProperty.call(data, k) ? data[k] : null;
      },
      setItem: function (k, v) {
        data[k] = String(v);
      },
      removeItem: function (k) {
        delete data[k];
      },
      clear: function () {
        data = {};
      },
      key: function (i) {
        return Object.keys(data)[i] || null;
      },
      get length() {
        return Object.keys(data).length;
      },
    };
  };
  ["localStorage", "sessionStorage"].forEach(function (name) {
    try {
      var s = W[name];
      s.setItem("__naira_preview_probe", "1");
      s.removeItem("__naira_preview_probe");
    } catch (e) {
      try {
        Object.defineProperty(W, name, { value: memoryStorage(), configurable: true });
        note("storage is in memory here", name);
      } catch (e2) {
        /* the shop guards its own storage calls */
      }
    }
  });
  var store = W.localStorage;

  /* ---------- the toast ---------- */
  var toastEl = null;
  var toastTimer = 0;
  var toast = function (text) {
    note("said", text);
    try {
      W.parent !== W && W.parent.postMessage({ type: MSG, kind: "said", text: text }, "*");
    } catch (e) {}
    var show = function () {
      if (!toastEl) {
        toastEl = document.createElement("div");
        toastEl.setAttribute("role", "status");
        toastEl.setAttribute("aria-live", "polite");
        toastEl.setAttribute("data-naira-preview-toast", "");
        toastEl.style.cssText =
          "position:fixed;left:50%;top:12px;transform:translate(-50%,-8px);z-index:2147483647;max-width:calc(100vw - 32px);" +
          "padding:9px 16px;background:#1A1614;color:#FBF3EC;border:1px solid rgba(201,154,76,.7);border-radius:999px;" +
          "font:400 12px/1.3 Jost,system-ui,sans-serif;letter-spacing:.04em;text-align:center;box-shadow:0 8px 28px rgba(26,22,20,.28);" +
          "opacity:0;transition:opacity .18s ease,transform .18s ease;pointer-events:none";
        (document.body || document.documentElement).appendChild(toastEl);
      }
      toastEl.textContent = text;
      // above a modal dialog's top layer too
      if (toastEl.parentNode !== document.body && document.body) document.body.appendChild(toastEl);
      requestAnimationFrame(function () {
        toastEl.style.opacity = "1";
        toastEl.style.transform = "translate(-50%,0)";
      });
      clearTimeout(toastTimer);
      toastTimer = setTimeout(function () {
        toastEl.style.opacity = "0";
        toastEl.style.transform = "translate(-50%,-8px)";
      }, 2800);
    };
    if (document.body) show();
    else document.addEventListener("DOMContentLoaded", show);
  };
  var NOT_HERE = "Not in this preview";
  var NO_CHECKOUT = "Checkout is switched off in this preview";

  /* ---------- addresses ---------- */
  var absolute = function (url) {
    try {
      return new URL(String(url), document.baseURI);
    } catch (e) {
      return null;
    }
  };
  var remote = function (url) {
    if (typeof url !== "string" || !url) return false;
    var u = absolute(url);
    return !!u && (u.protocol === "http:" || u.protocol === "https:" || u.protocol === "ws:" || u.protocol === "wss:") && u.origin !== location.origin;
  };

  /* ---------- photographs ---------- */
  /* In the fixtures and the code a Shopify photograph is ../media/<its file name>. At the tag it becomes
     its bundled copy (media/<name>.webp), or its small inline copy (kit/thumbs.js: every piece of the
     catalogue has one, for the corners that pick pieces at random), or a plain tile. */
  var THUMBS = W.__NAIRA_PREVIEW_THUMBS__ || {};
  var SIBLINGS = FX.siblings || {};
  var mediaDir = absolute(MEDIA_BASE) ? absolute(MEDIA_BASE).href : "";
  var REAL = { "_missing.svg": 1 };
  for (var bundled in MEDIA) REAL[MEDIA[bundled]] = 1;
  var thumbed = [];
  var nameOf = function (url) {
    var s = String(url);
    var cdn = cdnName(s);
    if (cdn !== null) return safeName(cdn);
    if (s.indexOf("media/") < 0) return null;
    var u = absolute(s);
    if (!u || !mediaDir || u.href.indexOf(mediaDir) !== 0) return null;
    var seg = u.pathname.slice(u.pathname.lastIndexOf("/") + 1);
    try {
      seg = decodeURIComponent(seg);
    } catch (e) {}
    return REAL[seg] ? null : seg;
  };
  var mediaUrl = function (url, el) {
    var name = nameOf(url);
    if (name === null) return null;
    if (MEDIA[name]) return MEDIA_BASE + MEDIA[name];
    if (THUMBS[name]) {
      if (el && thumbed.length < 4000) thumbed.push([el, name]);
      return THUMBS[name];
    }
    var stand = SIBLINGS[name];
    if (stand && (MEDIA[stand] || THUMBS[stand])) {
      if (el && thumbed.length < 4000) thumbed.push([el, name]);
      return MEDIA[stand] ? MEDIA_BASE + MEDIA[stand] : THUMBS[stand];
    }
    if (!missingMedia[name]) {
      missingMedia[name] = 1;
      note("photograph not bundled", name);
    }
    return MISSING;
  };
  /* A small copy drawn large wants its full photograph: the build's walk asks for these. */
  var scan = function () {
    thumbed.forEach(function (pair) {
      var el = pair[0];
      if (!el || !el.isConnected) return;
      var img = el.tagName === "SOURCE" && el.parentNode ? el.parentNode.querySelector("img") : el;
      var width = img && img.getBoundingClientRect ? img.getBoundingClientRect().width : 0;
      if (width > 150 && !missingMedia[pair[1]]) {
        missingMedia[pair[1]] = 1;
        note("photograph shown large from its small copy", pair[1] + " at " + Math.round(width) + "px");
      }
    });
    return missingMedia;
  };
  var TILE = "data:image/svg+xml," + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 4 5"><rect width="4" height="5" fill="#EFE6DC"/></svg>');
  var refused = {};
  var refuse = function (what, url) {
    var key = what + " " + url;
    if (refused[key]) return;
    refused[key] = 1;
    note(what + " refused", url);
  };
  var toImage = function (v, el) {
    v = String(v);
    var m = mediaUrl(v, el);
    if (m) return m;
    if (!remote(v)) return v;
    refuse("image", v);
    return TILE;
  };
  var toSrcset = function (v, el) {
    return String(v)
      .split(/,\s+|,(?=https?:)/)
      .map(function (part) {
        part = part.trim();
        if (!part) return "";
        var bits = part.split(/\s+/);
        var m = mediaUrl(bits[0], el);
        if (!m) {
          if (!remote(bits[0])) return part;
          refuse("image", bits[0]);
          return "";
        }
        bits[0] = m;
        return bits.join(" ");
      })
      .filter(Boolean)
      .join(", ");
  };
  var toNothing = function (kind, blank) {
    return function (v) {
      v = String(v);
      if (!remote(v)) return v;
      refuse(kind, v);
      return blank;
    };
  };
  var toMedia = function (v) {
    v = String(v);
    if (!remote(v)) return v;
    refuse("media", v);
    return "data:,";
  };
  var toLink = function (v) {
    v = String(v);
    var m = mediaUrl(v);
    if (m) return m;
    if (!remote(v)) return v;
    refuse("link", v);
    return "data:,";
  };
  var toCss = function (v) {
    v = String(v);
    if (v.indexOf("url(") < 0) return v;
    return v.replace(/url\(\s*(["']?)([^"')]+)\1\s*\)/g, function (whole, q, u) {
      var m = mediaUrl(u);
      if (m) return 'url("' + m + '")';
      if (!remote(u)) return whole;
      refuse("background", u);
      return 'url("' + TILE + '")';
    });
  };

  var patch = function (proto, prop, swap) {
    if (!proto) return;
    var d = Object.getOwnPropertyDescriptor(proto, prop);
    if (!d || !d.set || !d.get) return;
    Object.defineProperty(proto, prop, {
      configurable: true,
      enumerable: d.enumerable,
      get: d.get,
      set: function (v) {
        d.set.call(this, swap(v, this));
      },
    });
  };
  var blankScript = "data:text/javascript,";
  patch(HTMLImageElement.prototype, "src", toImage);
  patch(HTMLImageElement.prototype, "srcset", toSrcset);
  patch(HTMLSourceElement.prototype, "srcset", toSrcset);
  patch(HTMLSourceElement.prototype, "src", toMedia);
  patch(HTMLMediaElement.prototype, "src", toMedia);
  patch(HTMLVideoElement.prototype, "poster", toImage);
  patch(HTMLScriptElement.prototype, "src", toNothing("script", blankScript));
  patch(HTMLLinkElement.prototype, "href", toLink);
  patch(HTMLIFrameElement.prototype, "src", toNothing("frame", "about:blank"));
  patch(W.SVGImageElement && SVGImageElement.prototype, "href", toImage);
  var styleProto = W.CSSStyleDeclaration && CSSStyleDeclaration.prototype;
  ["backgroundImage", "background", "cssText", "maskImage", "webkitMaskImage"].forEach(function (p) {
    patch(styleProto, p, toCss);
  });
  if (styleProto && styleProto.setProperty) {
    var setProperty = styleProto.setProperty;
    styleProto.setProperty = function (name, value, priority) {
      return setProperty.call(this, name, value == null ? value : toCss(value), priority);
    };
  }
  var swapAttribute = function (el, name, value) {
    var n = String(name).toLowerCase();
    var v = String(value);
    if (n === "srcset" || n === "imagesrcset") return toSrcset(v, el);
    if (n === "src") {
      if (el instanceof HTMLImageElement) return toImage(v, el);
      if (el instanceof HTMLScriptElement) return toNothing("script", blankScript)(v);
      if (el instanceof HTMLIFrameElement) return toNothing("frame", "about:blank")(v);
      return toMedia(v);
    }
    if (n === "poster") return toImage(v);
    if (n === "href" && el instanceof HTMLLinkElement) return toLink(v);
    if ((n === "href" || n === "xlink:href") && W.SVGImageElement && el instanceof SVGImageElement) return toImage(v);
    if (n === "style") return toCss(v);
    return v;
  };
  var setAttribute = Element.prototype.setAttribute;
  Element.prototype.setAttribute = function (name, value) {
    return setAttribute.call(this, name, swapAttribute(this, name, value));
  };
  var setAttributeNS = Element.prototype.setAttributeNS;
  Element.prototype.setAttributeNS = function (ns, name, value) {
    return setAttributeNS.call(this, ns, name, swapAttribute(this, String(name).replace(/^.*:/, ""), value));
  };
  /* Anything written as markup (innerHTML, a static tag): mended as it lands. */
  var mend = function (el) {
    if (!el || el.nodeType !== 1) return;
    var fix = function (node) {
      ["src", "srcset", "poster", "imagesrcset"].forEach(function (a) {
        var v = node.getAttribute && node.getAttribute(a);
        if (!v) return;
        var next = swapAttribute(node, a, v);
        if (next !== v) setAttribute.call(node, a, next);
      });
      if (node instanceof HTMLLinkElement) {
        var h = node.getAttribute("href");
        var next = h ? toLink(h) : h;
        if (next !== h) setAttribute.call(node, "href", next);
      }
    };
    fix(el);
    if (el.querySelectorAll) Array.prototype.forEach.call(el.querySelectorAll("img,source,video,audio,iframe,script[src],link[href]"), fix);
  };
  try {
    new MutationObserver(function (records) {
      records.forEach(function (r) {
        if (r.type === "attributes") mend(r.target);
        else Array.prototype.forEach.call(r.addedNodes, mend);
      });
    }).observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ["src", "srcset", "poster", "href", "imagesrcset"] });
  } catch (e) {}

  /* ---------- the catalogue the fixtures hold ---------- */
  var byHandle = {};
  var byId = {};
  var variants = {};
  (function index() {
    var weigh = function (node) {
      return ((node.variants && (node.variants.edges || node.variants.nodes || []).length) || 0) + ((node.images && (node.images.edges || node.images.nodes || []).length) || 0) + (node.description ? 1 : 0);
    };
    var walk = function (v) {
      if (!v || typeof v !== "object") return;
      if (Array.isArray(v)) return void v.forEach(walk);
      if (typeof v.handle === "string" && v.variants && typeof v.title === "string") {
        var have = byHandle[v.handle];
        if (!have || weigh(v) > weigh(have)) {
          byHandle[v.handle] = v;
          if (v.id) byId[v.id] = v;
        }
        var list = v.variants.edges ? v.variants.edges.map(function (e) { return e.node; }) : v.variants.nodes || [];
        list.forEach(function (variant) {
          if (variant && variant.id && variant.price && !variants[variant.id]) variants[variant.id] = { variant: variant, product: v };
        });
      }
      for (var k in v) if (Object.prototype.hasOwnProperty.call(v, k)) walk(v[k]);
    };
    walk(QUERIES);
  })();

  /* ---------- the local cart ---------- */
  var CARTS_KEY = "naira-preview-carts";
  var RATES = { BUY2: [2, 0.1], BUY3: [3, 0.2], BUY4: [4, 0.3], NAIRA10: [1, 0.1], FRIENDSANDFAMILY: [1, 0.2] };
  var loadCarts = function () {
    try {
      return JSON.parse(store.getItem(CARTS_KEY) || "") || { seq: 0, carts: {} };
    } catch (e) {
      return { seq: 0, carts: {} };
    }
  };
  var saveCarts = function (state) {
    try {
      store.setItem(CARTS_KEY, JSON.stringify(state));
    } catch (e) {}
  };
  var money = function (n) {
    return { amount: (Math.round(n * 100) / 100).toFixed(1).replace(/\.(\d)$/, ".$1"), currencyCode: "INR" };
  };
  var sameAttributes = function (a, b) {
    var norm = function (list) {
      return (list || [])
        .map(function (x) {
          return x.key + "=" + x.value;
        })
        .sort()
        .join("&");
    };
    return norm(a) === norm(b);
  };
  var cartView = function (id, cart) {
    var lines = cart.lines.filter(function (l) {
      return l.quantity > 0;
    });
    var pieces = lines.reduce(function (n, l) {
      return n + l.quantity;
    }, 0);
    var codes = (cart.discountCodes || []).map(function (code) {
      var rule = RATES[String(code).toUpperCase()];
      return { code: code, applicable: !!rule && pieces >= rule[0], rate: rule && pieces >= rule[0] ? rule[1] : 0 };
    });
    var rate = codes.reduce(function (best, c) {
      return Math.max(best, c.rate);
    }, 0);
    var priced = lines.map(function (l) {
      var known = variants[l.merchandiseId];
      var price = known ? Number(known.variant.price.amount) : 0;
      return { line: l, known: known, price: price, exact: price * l.quantity * (1 - rate) };
    });
    // The bag's own arithmetic (src/lib/cartPricing.ts): floor each line, hand the rounded total's remainder to the largest fractions.
    var totals = priced.map(function (p) {
      return Math.floor(p.exact);
    });
    var subtotal = priced.reduce(function (n, p) {
      return n + p.price * p.line.quantity;
    }, 0);
    var target = Math.round(subtotal * (1 - rate));
    var left = target - totals.reduce(function (n, t) { return n + t; }, 0);
    priced
      .map(function (p, i) {
        return { i: i, f: p.exact - totals[i] };
      })
      .sort(function (a, b) {
        return b.f - a.f || a.i - b.i;
      })
      .slice(0, Math.max(0, left))
      .forEach(function (r) {
        totals[r.i] += 1;
      });
    var nodes = priced.map(function (p, i) {
      var v = p.known ? p.known.variant : null;
      var product = p.known ? p.known.product : null;
      var cut = p.price * p.line.quantity - totals[i];
      return {
        id: p.line.id,
        quantity: p.line.quantity,
        attributes: p.line.attributes || [],
        cost: {
          amountPerQuantity: money(p.price),
          compareAtAmountPerQuantity: v && v.compareAtPrice ? v.compareAtPrice : null,
          subtotalAmount: money(p.price * p.line.quantity),
          totalAmount: money(totals[i]),
        },
        discountAllocations: cut > 0 ? [{ discountedAmount: money(cut), code: codes.filter(function (c) { return c.rate === rate; })[0].code }] : [],
        merchandise: {
          __typename: "ProductVariant",
          id: p.line.merchandiseId,
          title: v ? v.title : "",
          availableForSale: v ? v.availableForSale !== false : true,
          price: v ? v.price : money(0),
          compareAtPrice: v ? v.compareAtPrice || null : null,
          selectedOptions: v ? v.selectedOptions || [] : [],
          sku: v ? v.sku || null : null,
          image: v && v.image ? v.image : product && product.images && product.images.edges && product.images.edges[0] ? product.images.edges[0].node : null,
          product: product ? { id: product.id, handle: product.handle, title: product.title, productType: product.productType, vendor: product.vendor, tags: product.tags } : null,
        },
      };
    });
    return {
      id: id,
      checkoutUrl: CHECKOUT,
      totalQuantity: pieces,
      note: "",
      attributes: cart.attributes || [],
      discountCodes: codes.map(function (c) {
        return { code: c.code, applicable: c.applicable };
      }),
      discountAllocations: [],
      buyerIdentity: { countryCode: "IN", email: null, phone: null, customer: null },
      cost: {
        subtotalAmount: money(target),
        totalAmount: money(target),
        checkoutChargeAmount: money(target),
        totalTaxAmount: null,
        totalDutyAmount: null,
      },
      lines: {
        edges: nodes.map(function (n) {
          return { cursor: n.id, node: n };
        }),
        nodes: nodes,
        pageInfo: { hasNextPage: false, hasPreviousPage: false, startCursor: null, endCursor: null },
      },
    };
  };
  var NO_CART = [{ field: ["cartId"], code: "INVALID", message: "The specified cart does not exist." }];
  var addLines = function (state, cart, lines) {
    (lines || []).forEach(function (input) {
      var known = variants[input.merchandiseId];
      // Shopify answers an Add of a sold-out piece with no line and no error.
      if (known && known.variant.availableForSale === false) return;
      var attributes = input.attributes || [];
      var same = cart.lines.filter(function (l) {
        return l.merchandiseId === input.merchandiseId && sameAttributes(l.attributes, attributes);
      })[0];
      if (same) same.quantity += input.quantity || 1;
      else cart.lines.push({ id: "gid://shopify/CartLine/preview-" + ++state.seq + "?cart=preview", quantity: input.quantity || 1, merchandiseId: input.merchandiseId, attributes: attributes });
    });
  };
  var CART_FIELDS = ["cartCreate", "cartLinesAdd", "cartLinesUpdate", "cartLinesRemove", "cartAttributesUpdate", "cartDiscountCodesUpdate", "cartBuyerIdentityUpdate", "cartNoteUpdate", "cartGiftCardCodesUpdate", "cartSelectedDeliveryOptionsUpdate"];
  var cartAnswer = function (query, vars) {
    var field = CART_FIELDS.filter(function (f) {
      return new RegExp("\\b" + f + "\\s*\\(").test(query);
    })[0];
    var state = loadCarts();
    var payload = function (name, cart, id, errors) {
      var data = {};
      data[name] = { cart: cart ? cartView(id, cart) : null, userErrors: errors || [], warnings: [] };
      return { data: data };
    };
    if (!field) {
      // query Cart($id)
      var qid = vars.id || vars.cartId;
      var found = state.carts[qid];
      return { data: { cart: found ? cartView(qid, found) : null } };
    }
    if (field === "cartCreate") {
      var input = vars.input || {};
      var id = "gid://shopify/Cart/preview-" + ++state.seq + "?key=preview";
      var fresh = { lines: [], attributes: input.attributes || [], discountCodes: input.discountCodes || [] };
      addLines(state, fresh, input.lines);
      state.carts[id] = fresh;
      saveCarts(state);
      note("cart: created", id);
      return payload(field, fresh, id);
    }
    var cartId = vars.cartId || vars.id;
    var cart = state.carts[cartId];
    if (!cart) return payload(field, null, cartId, NO_CART);
    var errors = [];
    if (field === "cartLinesAdd") addLines(state, cart, vars.lines);
    else if (field === "cartLinesUpdate") {
      (vars.lines || []).forEach(function (input) {
        var line = cart.lines.filter(function (l) {
          return l.id === input.id;
        })[0];
        if (!line) return void errors.push({ field: ["lines", "0", "id"], code: "INVALID_MERCHANDISE_LINE", message: "The merchandise line with id " + input.id + " does not exist." });
        if (typeof input.quantity === "number") line.quantity = input.quantity;
        if (input.attributes) line.attributes = input.attributes;
        if (input.merchandiseId) line.merchandiseId = input.merchandiseId;
      });
      cart.lines = cart.lines.filter(function (l) {
        return l.quantity > 0;
      });
    } else if (field === "cartLinesRemove") {
      (vars.lineIds || []).forEach(function (lineId) {
        var before = cart.lines.length;
        cart.lines = cart.lines.filter(function (l) {
          return l.id !== lineId;
        });
        if (cart.lines.length === before) errors.push({ field: ["lineIds", "0"], code: "INVALID_MERCHANDISE_LINE", message: "The merchandise line with id " + lineId + " does not exist." });
      });
    } else if (field === "cartAttributesUpdate") cart.attributes = vars.attributes || [];
    else if (field === "cartDiscountCodesUpdate") cart.discountCodes = vars.discountCodes || vars.codes || [];
    saveCarts(state);
    note("cart: " + field, cartId);
    return payload(field, cart, cartId, errors);
  };

  /* ---------- Storefront questions ---------- */
  var pageOf = function (list, first) {
    var cut = typeof first === "number" ? list.slice(0, first) : list;
    return {
      edges: cut.map(function (node) {
        return { cursor: node.id || node.handle, node: node };
      }),
      nodes: cut,
      pageInfo: { hasNextPage: false, hasPreviousPage: false, startCursor: null, endCursor: null },
    };
  };
  var fromPool = function (query, vars) {
    var all = Object.keys(byHandle).map(function (h) {
      return byHandle[h];
    });
    var data = {};
    if (/\bproducts\s*\(/.test(query)) data.products = pageOf(all, vars.first);
    if (/\b(product|productByHandle)\s*\(/.test(query)) {
      var found = null;
      Object.keys(vars).forEach(function (k) {
        var v = vars[k];
        if (typeof v === "string") found = found || byHandle[v] || byId[v] || null;
      });
      if (!found) {
        var literal = /\bproduct(?:ByHandle)?\s*\(\s*handle:\s*"([^"]+)"/.exec(query);
        if (literal) found = byHandle[literal[1]] || null;
      }
      data.product = found;
      if (/\bproductByHandle\s*\(/.test(query)) data.productByHandle = found;
    }
    if (/\bproductRecommendations\s*\(/.test(query)) data.productRecommendations = [];
    if (/\bcollection\s*\(/.test(query)) data.collection = null;
    if (/\bcollections\s*\(/.test(query)) data.collections = pageOf([], 0);
    if (/\bnodes\s*\(/.test(query)) data.nodes = [];
    return { data: data };
  };
  var storefront = function (body) {
    var q = {};
    try {
      q = JSON.parse(body || "{}") || {};
    } catch (e) {}
    var query = String(q.query || "");
    var vars = q.variables || {};
    if (/^\s*mutation\b/.test(query.replace(/#[^\n]*/g, "")) || /\bcart\s*\(/.test(query)) return cartAnswer(query, vars);
    var key = queryKey(query, vars);
    if (Object.prototype.hasOwnProperty.call(QUERIES, key)) {
      hits[key] = 1;
      return QUERIES[key];
    }
    misses.push({ key: key, query: query, variables: vars });
    note("Storefront question not in the fixtures: answered from the catalogue they hold", query.replace(/\s+/g, " ").slice(0, 80));
    return fromPool(query, vars);
  };

  /* ---------- fetch, XHR, beacons, sockets ---------- */
  var json = function (data, status, headers) {
    var h = { "content-type": "application/json" };
    for (var k in headers || {}) h[k] = headers[k];
    return new Response(status === 204 ? null : JSON.stringify(data), { status: status || 200, headers: h });
  };
  var answer = function (url, method, body, accept) {
    var u = absolute(url);
    var host = u ? u.hostname : "";
    var path = u ? u.pathname : "";
    if (/\/api\/[^/]+\/graphql(\.json)?$/.test(path) && /shopify|nairaflore/.test(host)) {
      return json(storefront(body));
    }
    if (/supabase/.test(host)) {
      /* The reels: their rows as the shop's own select returns them, and the "signed" addresses of their
         films and posters, which here are files in dist/reels. (No reels bundled: the empty answers below,
         and the shop draws no reel section.) */
      if (REELS && path === "/rest/v1/reels" && (method === "GET" || method === "HEAD")) {
        note("reels answered from the bundle", REELS.rows.length);
        return json(REELS.rows, 200, { "content-range": "0-" + Math.max(0, REELS.rows.length - 1) + "/*" });
      }
      if (REELS && path === "/functions/v1/reel-media") {
        note("reel films answered from the bundle", Object.keys(REELS.urls).length);
        return json({ urls: REELS.urls });
      }
      note("Supabase answered empty", method + " " + path);
      if (path.indexOf("/auth/v1/") === 0) return json({ code: 400, error_code: "preview", msg: "Sign-in is switched off in this preview" }, 400);
      if (path.indexOf("/rest/v1/rpc/") === 0) return json(null);
      var reads = method === "GET" || method === "HEAD";
      if (path.indexOf("/rest/v1/") === 0) {
        // Nothing is written from the preview: a review or a sign-up gets the shop's own "could not send".
        if (!reads) return json({ code: "PREVIEW", details: null, hint: null, message: "Nothing is sent from this preview" }, 403);
        if (/vnd\.pgrst\.object/.test(accept || "")) return json({ code: "PGRST116", details: "The result contains 0 rows", hint: null, message: "JSON object requested, multiple (or no) rows returned" }, 406);
        return json([], 200, { "content-range": "*/0" });
      }
      if (path.indexOf("/storage/v1/") === 0) return reads ? json([]) : json({ statusCode: "403", error: "preview", message: "Nothing is sent from this preview" }, 403);
      return json({});
    }
    refuse("fetch", url);
    return json({ preview: true });
  };
  var realFetch = W.fetch ? W.fetch.bind(W) : null;
  W.fetch = function (input, init) {
    var url = typeof input === "string" ? input : input && input.href ? input.href : input && input.url;
    if (!remote(String(url))) return realFetch(input, init);
    init = init || {};
    var isRequest = typeof Request !== "undefined" && input instanceof Request;
    var method = String(init.method || (isRequest ? input.method : "GET")).toUpperCase();
    var accept = "";
    try {
      accept = new Headers(init.headers || (isRequest ? input.headers : undefined)).get("accept") || "";
    } catch (e) {}
    var body = typeof init.body === "string" ? Promise.resolve(init.body) : isRequest && !init.body ? input.clone().text().catch(function () { return ""; }) : Promise.resolve("");
    return body.then(function (text) {
      return answer(String(url), method, text, accept);
    });
  };
  var xhrOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url) {
    var args = Array.prototype.slice.call(arguments);
    if (remote(String(url))) {
      refuse("XMLHttpRequest", String(url));
      args[1] = "data:application/json,%7B%7D";
      args[0] = "GET";
    }
    return xhrOpen.apply(this, args);
  };
  if (navigator.sendBeacon) {
    try {
      navigator.sendBeacon = function (url) {
        refuse("beacon", String(url));
        return true;
      };
    } catch (e) {}
  }
  ["WebSocket", "EventSource"].forEach(function (name) {
    if (!W[name]) return;
    var Quiet = function (url) {
      refuse(name, String(url));
      this.readyState = 3;
      this.url = String(url);
    };
    Quiet.prototype = { close: function () {}, send: function () {}, addEventListener: function () {}, removeEventListener: function () {}, dispatchEvent: function () { return false; } };
    Quiet.CONNECTING = 0;
    Quiet.OPEN = 1;
    Quiet.CLOSING = 2;
    Quiet.CLOSED = 3;
    try {
      W[name] = Quiet;
    } catch (e) {}
  });
  /* The trackers' own queues, so the shop's calls land somewhere and nothing loads. */
  if (!W.fbq) {
    var fbq = function () {
      fbq.queue.push(arguments);
    };
    fbq.queue = [];
    fbq.loaded = true;
    fbq.version = "2.0";
    fbq.push = fbq;
    W.fbq = W._fbq = fbq;
  }
  if (!W.clarity) {
    W.clarity = function () {
      (W.clarity.q = W.clarity.q || []).push(arguments);
    };
  }
  W.__fbLoad = function () {};

  /* ---------- routes ---------- */
  var routeOf = function (path) {
    var m = /^\/(?:preview\/)?(?:jewellery|jewelry)\/([^\/?#]+)\/?$/.exec(path || "");
    return m ? decodeURIComponent(m[1]) : null;
  };
  var allows = function (path) {
    var handle = routeOf(String(path || "").split(/[?#]/)[0]);
    return !!handle && handle !== "collections" && (SIX.length === 0 || SIX.indexOf(handle) >= 0);
  };
  var lastSaid = 0;
  var refusedRoute = function (path) {
    var now = Date.now();
    if (now - lastSaid < 400) return;
    lastSaid = now;
    toast(String(path || "").indexOf("/preview-checkout") === 0 ? NO_CHECKOUT : NOT_HERE);
  };
  var current = null;
  var tellShell = function (kind, more) {
    var m = { type: MSG, kind: kind, build: BUILD, handle: current };
    for (var k in more || {}) m[k] = more[k];
    try {
      if (W.parent && W.parent !== W) W.parent.postMessage(m, "*");
    } catch (e) {}
  };

  /* ---------- history: a step back never leaves the preview ----------
     The product page's own back arrow (and every overlay that closes "the way back would") calls
     history.back(). In a frame that walks the whole tab's history: on a page just opened there is
     nothing of ours behind it, so the tab itself went back, out of the preview. Every entry this
     document makes is numbered (__nairaDepth in its state); a step back past the first one is
     refused with the note instead. */
  var H = W.history;
  var rawPush = H.pushState;
  var rawReplace = H.replaceState;
  var rawGo = H.go;
  var depthOf = function (state) {
    return state && typeof state === "object" && typeof state.__nairaDepth === "number" ? state.__nairaDepth : null;
  };
  var withDepth = function (state, d) {
    var out = {};
    if (state && typeof state === "object") for (var key in state) out[key] = state[key];
    out.__nairaDepth = d;
    return out;
  };
  var lastDepth = 0;
  try {
    var born = depthOf(H.state);
    if (born === null) rawReplace.call(H, withDepth(H.state, 0), "");
    else lastDepth = born;
    /* An entry without a number is one a fragment made (location.hash, a plain #link): one deeper than the last. */
    var depthNow = function () {
      var d = depthOf(H.state);
      return d === null ? lastDepth + 1 : d;
    };
    var number = function () {
      var d = depthOf(H.state);
      if (d === null) {
        d = lastDepth + 1;
        try {
          rawReplace.call(H, withDepth(H.state, d), "");
        } catch (e) {}
      }
      lastDepth = d;
    };
    H.pushState = function (state, title, url) {
      var d = depthNow() + 1;
      var r = arguments.length > 2 ? rawPush.call(H, withDepth(state, d), title, url) : rawPush.call(H, withDepth(state, d), title);
      lastDepth = d;
      return r;
    };
    H.replaceState = function (state, title, url) {
      var d = depthNow();
      var r = arguments.length > 2 ? rawReplace.call(H, withDepth(state, d), title, url) : rawReplace.call(H, withDepth(state, d), title);
      lastDepth = d;
      return r;
    };
    H.go = function (n) {
      n = Number(n) || 0;
      if (n < 0 && depthNow() + n < 0) {
        note("a step back out of the preview was refused", String(n));
        return void toast(NOT_HERE);
      }
      return rawGo.call(H, n);
    };
    H.back = function () {
      return H.go(-1);
    };
    W.addEventListener("popstate", number, true);
    W.addEventListener("hashchange", number, true);
  } catch (e) {
    note("history could not be numbered", e && e.message);
  }

  /* The page opens on ?p=<handle> (or the first of the six). */
  (function open() {
    var hash = location.hash || "";
    if (/^#\//.test(hash) && allows(hash.slice(1))) return;
    var p = params.get("p");
    var handle = p && (SIX.length === 0 || SIX.indexOf(p) >= 0) ? p : SIX[0] || p || "";
    var colour = params.get("colour");
    try {
      history.replaceState(null, "", location.pathname + location.search + "#/jewellery/" + encodeURIComponent(handle) + (colour ? "?colour=" + encodeURIComponent(colour) : ""));
    } catch (e) {
      location.hash = "#/jewellery/" + encodeURIComponent(handle);
    }
  })();

  /* Checkout never leaves. Its address is local (#/preview-checkout); where the browser lets the
     page veto a move it is stopped outright, and the hash router refuses it everywhere else. */
  try {
    if (W.navigation && W.navigation.addEventListener) {
      W.navigation.addEventListener("navigate", function (e) {
        var dest = e.destination && e.destination.url ? absolute(e.destination.url) : null;
        if (!dest || !e.cancelable) return;
        var checkout = dest.hash.indexOf(CHECKOUT) === 0;
        // The shell moves this frame between before/ and after/ (and reloads it): those stay allowed.
        var inPreview = dest.origin === location.origin && (dest.pathname === location.pathname || /\/(before|after)\/(index\.html)?$/.test(dest.pathname));
        var away = !inPreview;
        if (!checkout && !away) return;
        e.preventDefault();
        toast(checkout || /checkout|payments\.|\/cart\//.test(dest.href) ? NO_CHECKOUT : NOT_HERE);
      });
    }
  } catch (e) {}
  W.open = function (url) {
    note("a new window would open", String(url || ""));
    toast(NOT_HERE);
    return null;
  };
  if (navigator.share) {
    try {
      navigator.share = function () {
        toast(NOT_HERE);
        return Promise.resolve();
      };
    } catch (e) {}
  }
  document.addEventListener(
    "click",
    function (e) {
      var a = e.target && e.target.closest ? e.target.closest("a[href]") : null;
      if (!a) return;
      var raw = a.getAttribute("href") || "";
      if (/^(mailto|tel|sms|whatsapp):/i.test(raw) || remote(a.href)) {
        e.preventDefault();
        e.stopPropagation();
        note("a link out", a.href);
        return void toast(NOT_HERE);
      }
      // A plain <a href="/jewellery/x"> (not a router link) would leave the document: keep it in the hash.
      if (raw.charAt(0) === "/" && raw.charAt(1) !== "/") {
        e.preventDefault();
        e.stopPropagation();
        if (allows(raw)) location.hash = "#" + raw;
        else toast(NOT_HERE);
        return;
      }
      if (a.target === "_blank" && raw.charAt(0) === "#") {
        e.preventDefault();
        e.stopPropagation();
        if (allows(raw.slice(1))) location.hash = raw;
        else toast(NOT_HERE);
      }
    },
    true,
  );
  document.addEventListener(
    "submit",
    function (e) {
      var f = e.target;
      var action = f && f.getAttribute ? f.getAttribute("action") : null;
      if (action && remote(absolute(action) ? absolute(action).href : "")) {
        e.preventDefault();
        toast(NOT_HERE);
      }
    },
    true,
  );

  /* ---------- Title A / B (after only) ---------- */
  var setTitle = function (v) {
    if (BUILD !== "after") return;
    document.documentElement.setAttribute("data-pdp-title", v === "b" || v === "c" ? v : "a");
  };
  if (BUILD === "after") {
    setTitle(params.get("title") || "a");
    var addOverride = function () {
      if (document.querySelector("link[data-naira-preview-title]")) return;
      var link = document.createElement("link");
      link.rel = "stylesheet";
      link.href = "../title-b.css";
      link.setAttribute("data-naira-preview-title", "");
      document.head.appendChild(link);
    };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", addOverride);
    else addOverride();
  }

  /* ---------- the bag: two pieces, then open ---------- */
  var BAG_KEY = "naira-shopify-cart";
  var seedBag = function () {
    var items = FX.bag || [];
    if (!items.length) return;
    var state = loadCarts();
    var id = "gid://shopify/Cart/preview-" + ++state.seq + "?key=preview";
    var cart = { lines: [], attributes: [], discountCodes: [] };
    var stored = items.map(function (item) {
      var lineId = "gid://shopify/CartLine/preview-" + ++state.seq + "?cart=preview";
      cart.lines.push({ id: lineId, quantity: item.quantity || 1, merchandiseId: item.variantId, attributes: item.size ? [{ key: "Size", value: item.size }] : [] });
      var copy = {};
      for (var k in item) copy[k] = item[k];
      copy.lineId = lineId;
      copy.quantity = item.quantity || 1;
      return copy;
    });
    state.carts[id] = cart;
    saveCarts(state);
    try {
      store.setItem(BAG_KEY, JSON.stringify({ items: stored, cartId: id, checkoutUrl: CHECKOUT }));
    } catch (e) {}
    note("bag: two pieces put in", id);
  };
  var BAG_BUTTONS = ['[data-preview-open-bag]', 'button[aria-label^="Open cart"]', 'button[aria-label^="Open bag"]', 'button[aria-label*="bag" i][aria-haspopup]', 'a[aria-label^="Open cart"]'];
  var openBag = function (tries) {
    tries = tries || 0;
    var open = document.querySelector('[role="dialog"][data-state="open"]');
    if (open && /bag|cart/i.test(open.textContent || "")) return;
    var button = null;
    for (var i = 0; i < BAG_BUTTONS.length && !button; i++) {
      var found = document.querySelectorAll(BAG_BUTTONS[i]);
      for (var j = 0; j < found.length && !button; j++) if (found[j].offsetParent !== null || found[j].getClientRects().length) button = found[j];
    }
    if (button) return void button.click();
    if (tries < 120) setTimeout(function () { openBag(tries + 1); }, 150);
    else note("bag: no button found to open it", BAG_BUTTONS.join(", "));
  };
  if (params.get("bag") === "1") {
    seedBag();
    var whenUp = function () {
      setTimeout(openBag, 350);
    };
    if (document.readyState === "complete") whenUp();
    else W.addEventListener("load", whenUp);
  } else if (params.get("bag") === "0") {
    try {
      store.removeItem(BAG_KEY);
    } catch (e) {}
  }

  W.addEventListener("message", function (e) {
    var m = e.data;
    if (!m || typeof m !== "object" || m.type !== MSG) return;
    if (m.cmd === "title") setTitle(m.value);
    if (m.cmd === "open-bag") openBag();
    if (m.cmd === "where") tellShell("route");
  });

  W.__nairaPreview = {
    build: BUILD,
    six: SIX,
    log: log,
    misses: misses,
    hits: hits,
    missingMedia: missingMedia,
    scan: scan,
    allows: allows,
    refused: refusedRoute,
    route: function (path) {
      current = routeOf(path);
      tellShell("route");
    },
    toast: toast,
    openBag: openBag,
    setTitle: setTitle,
    products: function () {
      return Object.keys(byHandle);
    },
  };
  W.addEventListener("load", function () {
    tellShell("ready");
  });
})();
