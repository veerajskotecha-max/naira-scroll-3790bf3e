/*
  How a Storefront question is named in the fixtures: the query with its
  whitespace folded, then its variables with their keys in order, hashed.
  The same function runs in the guard (browser) and in the recorder (Node).
*/
function stable(v) {
  if (v === null || typeof v !== "object") return JSON.stringify(v === undefined ? null : v);
  if (Array.isArray(v)) return "[" + v.map(stable).join(",") + "]";
  return (
    "{" +
    Object.keys(v)
      .filter(function (k) {
        return v[k] !== undefined;
      })
      .sort()
      .map(function (k) {
        return JSON.stringify(k) + ":" + stable(v[k]);
      })
      .join(",") +
    "}"
  );
}
function queryKey(query, variables) {
  var s = String(query || "").replace(/#[^\n]*/g, " ").replace(/\s+/g, " ").trim() + "|" + stable(variables || {});
  var h1 = 0x811c9dc5,
    h2 = 0x1b873593;
  for (var i = 0; i < s.length; i++) {
    var c = s.charCodeAt(i);
    h1 = Math.imul(h1 ^ c, 16777619);
    h2 = Math.imul(h2 + c, 0x85ebca6b) ^ (h2 >>> 13);
  }
  return ("0000000" + (h1 >>> 0).toString(16)).slice(-8) + ("0000000" + (h2 >>> 0).toString(16)).slice(-8);
}
/* A Shopify CDN address -> the photograph's file name (no folder, no version, no width). */
var CDN_ONE = /^https?:\/\/cdn\.shopify\.com\/[^?#\s]*\/([^\/?#\s]+)(?:\?[^#\s]*)?(?:#.*)?$/;
function cdnName(url) {
  var m = CDN_ONE.exec(String(url || ""));
  if (!m) return null;
  try {
    return decodeURIComponent(m[1]);
  } catch (e) {
    return m[1];
  }
}
/* A photograph's name as the preview spells it: the original file name, extension and all (the shop's
   code matches on names), with anything unsafe in a path made an underscore. In data it is addressed
   as ../media/<name>; the copy on disk is <name>.webp, and the guard swaps one for the other at the tag. */
function safeName(name) {
  return String(name).replace(/[^A-Za-z0-9._-]/g, "_");
}
function localName(name) {
  return safeName(name) + ".webp";
}
if (typeof module !== "undefined" && module.exports) module.exports = { queryKey: queryKey, stable: stable, cdnName: cdnName, safeName: safeName, localName: localName };
