/*
  Puts the preview together in dist/ from the two raw builds (.work/raw-before,
  .work/raw-after), the recorded answers and the cached photographs and fonts:

    dist/index.html          the shell (ribbon, switches, the frame)
    dist/before/index.html   today's shop          } both load ../assets/app-<hash>.js;
    dist/after/index.html    the redesign          } identical files are shared
    dist/assets/             the shop's hashed code, styles and bundled pictures
    dist/kit/guard.js        the network guard, dist/kit/fixtures.js the answers
    dist/media/              Shopify photographs, WebP, one copy for both builds
    dist/reels/              the reels' films and posters (as the shop serves them)
    dist/fonts/              Cormorant Garamond, Jost, Velista
    dist/title-b.css         the Title B override

  Fast (no Vite): it is run again after every recording round.
*/
const { fs, path, KIT, CACHE, WORK, DIST, CONFIG, SIX, QUERIES_FILE, MEDIA_DIR, THUMBS_DIR, WANTED_FILE, readJson, walk, CDN_ALL, productsIn, cdnUrlsIn, cdnName, safeName, localName, photosOf, variantPhotosOf } = require("./lib.cjs");
const { createRequire } = require("node:module");

const SRC_FOR_TOOLS = process.env.PREVIEW_BEFORE_SRC || "/tmp/pdp-base";
const esbuild = createRequire(path.join(SRC_FOR_TOOLS, "package.json"))("esbuild");

const ascii = (s) => s.replace(/[\u007f-￿]/g, (c) => "\\u" + c.charCodeAt(0).toString(16).padStart(4, "0"));
const MEDIA_REL = "../media/";

const main = () => {
  fs.rmSync(DIST, { recursive: true, force: true });
  for (const d of ["assets", "kit", "media", "fonts", "before", "after"]) fs.mkdirSync(path.join(DIST, d), { recursive: true });

  /* ---- which photographs are bundled ---- */
  const cache = readJson(QUERIES_FILE, {});
  const responses = Object.values(cache).map((e) => e.response);
  const products = productsIn(responses);
  const wanted = new Set(Object.keys(readJson(WANTED_FILE, {})));
  for (const handle of SIX) for (const url of cdnUrlsIn(products.get(handle) ?? {})) wanted.add(safeName(cdnName(url)));
  const media = {};
  for (const name of wanted) {
    const file = localName(name);
    const from = path.join(MEDIA_DIR, file);
    if (!fs.existsSync(from) || !fs.statSync(from).size) continue;
    fs.copyFileSync(from, path.join(DIST, "media", file));
    media[name] = file;
  }
  fs.writeFileSync(
    path.join(DIST, "media/_missing.svg"),
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 4 5" preserveAspectRatio="none"><rect width="4" height="5" fill="#EFE6DC"/></svg>\n',
  );
  /* The small inline copies (every piece's first photographs), for whatever is not bundled in full. */
  const thumbs = {};
  for (const name of readJson(path.join(CACHE, "thumb-names.json"), [])) {
    const from = path.join(THUMBS_DIR, `${name}.webp`);
    if (media[name] || !fs.existsSync(from) || !fs.statSync(from).size) continue;
    thumbs[name] = `data:image/webp;base64,${fs.readFileSync(from).toString("base64")}`;
  }
  /* A photograph with neither stands in as another photograph of the same piece. */
  const siblings = {};
  for (const node of products.values()) {
    const names = [...photosOf(node).map((p) => p.url), ...cdnUrlsIn(node)].map((u) => safeName(cdnName(u)));
    const stand = names.find((n) => media[n] || thumbs[n]);
    if (stand) for (const n of new Set(names)) if (!media[n] && !thumbs[n]) siblings[n] = stand;
  }
  /* In data, a Shopify photograph is ../media/<its own file name>: the guard picks the copy at the tag. */
  const localise = (url) => {
    const name = cdnName(url);
    return name === null ? url : MEDIA_REL + safeName(name);
  };
  const localiseText = (text) => text.replace(CDN_ALL, (url) => localise(url.replace(/\\u0026/g, "&")));

  /* ---- the two builds ---- */
  const apps = {};
  for (const name of ["before", "after"]) {
    const raw = path.join(WORK, `raw-${name}`);
    if (!fs.existsSync(path.join(raw, "index.html"))) throw new Error(`no raw build for "${name}" (${raw}): run build.sh`);
    for (const f of walk(path.join(raw, "assets"))) {
      const to = path.join(DIST, "assets", path.relative(path.join(raw, "assets"), f));
      if (fs.existsSync(to)) continue;
      fs.mkdirSync(path.dirname(to), { recursive: true });
      if (/\.(js|css)$/.test(f)) fs.writeFileSync(to, localiseText(fs.readFileSync(f, "utf8")));
      else fs.copyFileSync(f, to);
    }
    const html = fs.readFileSync(path.join(raw, "index.html"), "utf8").replace(/(["'(])\.\/assets\//g, "$1../assets/");
    apps[name] = /assets\/(app-[^"']+\.js)/.exec(html)?.[1] ?? null;
    fs.writeFileSync(path.join(DIST, name, "index.html"), localiseText(html));
  }

  /* ---- the guard and the fixtures ---- */
  const guardSource = `(function(){\n${fs.readFileSync(path.join(KIT, "guard/key.js"), "utf8")}\n${fs.readFileSync(path.join(KIT, "guard/guard.js"), "utf8")}\n})();`;
  const guard = esbuild.transformSync(guardSource, { minify: true, charset: "ascii", target: "es2018", legalComments: "none" }).code;
  fs.writeFileSync(path.join(DIST, "kit/guard.js"), guard);

  const rewrite = (v) => {
    if (typeof v === "string") return cdnName(v) !== null ? localise(v) : v.includes("cdn.shopify.com") ? localiseText(v) : v;
    if (Array.isArray(v)) return v.map(rewrite);
    if (v && typeof v === "object") return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, rewrite(x)]));
    return v;
  };
  /* --prune: only the answers the last walk used (an answer to a question no page asks any more is left out). */
  const used = process.argv.includes("--prune") ? readJson(path.join(WORK, "used-queries.json"), []) : [];
  const kept = Object.entries(cache).filter(([key]) => !used.length || used.includes(key));
  const queries = Object.fromEntries(kept.map(([key, entry]) => [key, rewrite(entry.response)]));

  const NOT_A_COVER = /size[-_ ]?guide|naira[-_ ]?packaging|gift\s*box|shipping\s*carton/i;
  const bag = (CONFIG.bag || [])
    .map((handle) => {
      const node = products.get(handle);
      const variants = node?.variants?.edges?.map((e) => e.node) ?? [];
      const variant = variants.find((v) => v.availableForSale) ?? variants[0];
      if (!node || !variant) return null;
      const images = (node.images?.edges ?? []).map((e) => e.node).filter((i) => (i.altText ?? "").trim().toLowerCase() !== "catalog-square");
      const cover = images.find((i) => !NOT_A_COVER.test(`${i.url} ${i.altText ?? ""}`)) ?? images[0];
      const price = Number(variant.price.amount);
      const options = (variant.selectedOptions ?? []).filter((o) => !/^title$/i.test(o.name));
      return {
        id: handle,
        variantId: variant.id,
        name: node.title,
        price,
        priceLabel: `₹${price.toLocaleString("en-IN")}`,
        currencyCode: "INR",
        image: cover ? localise(cover.url) : "",
        quantity: 1,
        ...(options.length ? { selectedOptions: options, variantTitle: variant.title } : {}),
        ...(/^\s*rings?\s*$/i.test(node.productType || "") && !options.some((o) => /size/i.test(o.name)) ? { size: "US 6" } : {}),
      };
    })
    .filter(Boolean);

  /* ---- the reels: the rows the shop reads from Supabase, and their films and posters as files (scripts/reels.cjs) ---- */
  let reels = null;
  const reelsHeld = CONFIG.reels === false ? null : readJson(path.join(CACHE, "reels/reels.json"), null);
  if (reelsHeld && Array.isArray(reelsHeld.rows) && reelsHeld.rows.length) {
    const urls = {};
    for (const [storagePath, file] of Object.entries(reelsHeld.files || {})) {
      const from = path.join(CACHE, "reels", file);
      if (!fs.existsSync(from) || !fs.statSync(from).size) continue;
      fs.mkdirSync(path.join(DIST, "reels"), { recursive: true });
      fs.copyFileSync(from, path.join(DIST, "reels", file));
      urls[storagePath] = "../reels/" + file;
    }
    reels = { rows: rewrite(reelsHeld.rows), urls };
  }

  const fixtures = {
    builtAt: new Date().toISOString(),
    six: SIX,
    products: CONFIG.products,
    bag,
    media,
    siblings,
    queries,
    reels,
  };
  fs.writeFileSync(path.join(DIST, "kit/fixtures.js"), `window.__NAIRA_PREVIEW_FIXTURES__=${ascii(JSON.stringify(fixtures))};\n`);
  fs.writeFileSync(path.join(DIST, "kit/thumbs.js"), `window.__NAIRA_PREVIEW_THUMBS__=${JSON.stringify(thumbs)};\n`);

  /* ---- fonts, the Title B override, the shell ---- */
  const FONTS = path.join(CACHE, "fonts");
  for (const f of fs.existsSync(FONTS) ? fs.readdirSync(FONTS) : []) if (/\.(woff2|ttf)$/.test(f)) fs.copyFileSync(path.join(FONTS, f), path.join(DIST, "fonts", f));
  fs.writeFileSync(path.join(DIST, "fonts/fonts.css"), fs.existsSync(path.join(FONTS, "google.css")) ? fs.readFileSync(path.join(FONTS, "google.css"), "utf8") : "");
  fs.copyFileSync(path.join(KIT, "title-b.css"), path.join(DIST, "title-b.css"));

  const sameBuild = apps.before && apps.before === apps.after;
  const shell = fs
    .readFileSync(path.join(KIT, "shell/index.html"), "utf8")
    .replace("/*__PREVIEW_CONFIG__*/", `window.__NAIRA_PREVIEW_SHELL__=${ascii(JSON.stringify({ products: CONFIG.products, same: !!sameBuild, builtAt: fixtures.builtAt }))};`);
  fs.writeFileSync(path.join(DIST, "index.html"), shell);
  fs.writeFileSync(path.join(WORK, "same.json"), JSON.stringify({ same: !!sameBuild }));

  const files = walk(DIST);
  console.log(
    `assemble: ${files.length} files, ${Object.keys(media).length} photographs in full, ${Object.keys(thumbs).length} small copies, ${Object.keys(queries).length} recorded answers, ${bag.length} bag pieces, ${reels ? reels.rows.length : 0} reels` +
      (sameBuild ? "; before and after are the same build today (one shared bundle)" : ""),
  );
};

main();
