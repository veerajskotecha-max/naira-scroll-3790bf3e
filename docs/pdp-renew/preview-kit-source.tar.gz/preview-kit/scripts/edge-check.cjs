/*
  Three conditions the main check does not meet in Chromium, tried on purpose
  (run it after build.sh; it serves dist/ on 127.0.0.1:4410 like check.cjs):

  1. a browser with no Navigation API (Safari before 26.2): Checkout, Buy now
     and a typed address elsewhere must still stay on the page, with the note;
  2. a frame with no storage (a sandboxed page): the page, "Open the bag" and
     its totals must still work, from the guard's memory storage;
  3. the shell opened on a state in its address, at 360x640.

    node scripts/edge-check.cjs
*/
const { path, WORK, fs } = require("./lib.cjs");
const { chromium } = require("playwright");
const { serve, guarded, openPiece, BASE } = require("./walk.cjs");

(async () => {
  const server = await serve();
  const browser = await chromium.launch({ args: ["--disable-blink-features=AutomationControlled"] }) /* navigator.webdriver false: the shop holds back its later gallery photographs, reels and delivery dates from an automated browser, and the walk must see what a shopper sees */;
  const bagSel = '[role="dialog"][data-state="open"]';
  const shots = path.join(WORK, "shots");
  fs.mkdirSync(shots, { recursive: true });
  const failures = [];
  const expect = (ok, what) => (ok ? console.log(`  ok  ${what}`) : failures.push(what));
  const toast = (page) => page.evaluate(() => document.querySelector("[data-naira-preview-toast]")?.textContent || "");
  try {
    {
      const sink = { outside: [], errors: [] };
      const { context, page } = await guarded(browser, "phone", sink);
      await context.addInitScript(() => {
        try {
          Object.defineProperty(window, "navigation", { value: undefined, configurable: true });
        } catch (e) {}
      });
      await openPiece(page, "after", "woven-gold-hoops", "&bag=1");
      await page.waitForSelector(bagSel, { timeout: 15000 });
      await page.locator(`${bagSel} button:has-text("Checkout")`).last().click();
      await page.waitForTimeout(1500);
      expect((await toast(page)).includes("Checkout is switched off") && (await page.evaluate(() => location.hash)) === "#/jewellery/woven-gold-hoops" && (await page.locator("#root h1").count()) > 0, "no Navigation API: Checkout stays on the page, with the note");
      await page.screenshot({ path: path.join(shots, "edge-no-navigation-api-checkout.png") });
      await openPiece(page, "after", "prism-riviere-bracelet", "&bag=0");
      await page.locator('#root button:has-text("Buy now")').first().click();
      await page.waitForTimeout(1800);
      expect((await toast(page)).includes("Checkout is switched off") && (await page.evaluate(() => location.hash)) === "#/jewellery/prism-riviere-bracelet", "no Navigation API: Buy now stays on the page, with the note");
      await page.evaluate(() => (location.hash = "#/jewellery"));
      await page.waitForTimeout(900);
      expect((await toast(page)).includes("Not in this preview") && (await page.evaluate(() => location.hash)) === "#/jewellery/prism-riviere-bracelet", "an address outside the six, typed: refused, and the page stays");
      expect(sink.outside.length === 0 && sink.errors.length === 0, `no outside request, no console error (${[...sink.outside, ...sink.errors].slice(0, 3).join(" | ")})`);
      await context.close();
    }
    {
      const sink = { outside: [], errors: [] };
      const { context, page } = await guarded(browser, "phone", sink);
      await context.addInitScript(() => {
        for (const name of ["localStorage", "sessionStorage"]) Object.defineProperty(window, name, { get() { throw new DOMException("blocked", "SecurityError"); }, configurable: true });
      });
      await openPiece(page, "after", "cushion-halo-ring", "&bag=1");
      await page.waitForSelector(bagSel, { timeout: 15000 }).catch(() => {});
      const said = await page.evaluate((sel) => (document.querySelector(sel)?.innerText || "").replace(/\s+/g, " "), bagSel);
      expect(/2 PIECES/i.test(said) && /10% for 2 pieces/i.test(said), "no storage: the bag opens with two pieces and its 10%");
      await page.screenshot({ path: path.join(shots, "edge-no-storage-bag.png") });
      expect(sink.outside.length === 0 && sink.errors.length === 0, `no outside request, no console error (${[...sink.outside, ...sink.errors].slice(0, 3).join(" | ")})`);
      await context.close();
    }
    {
      const sink = { outside: [], errors: [] };
      const { context, page } = await guarded(browser, "small", sink);
      await page.goto(`${BASE}/index.html?v=before&p=clover-trio-edit&bag=1`);
      await page.frameLocator("#frame").locator(bagSel).first().waitFor({ timeout: 15000 });
      await page.waitForTimeout(600);
      await page.screenshot({ path: path.join(shots, "edge-shell-360-before-bag.png") });
      const pressed = await page.evaluate(() => document.querySelector('[data-build="before"]').getAttribute("aria-pressed"));
      expect(pressed === "true" && /v=before&p=clover-trio-edit/.test(page.url()), "the shell opens on the state in its address (Before, Clover Trio Edit, the bag)");
      expect(sink.outside.length === 0 && sink.errors.length === 0, `no outside request, no console error (${[...sink.outside, ...sink.errors].slice(0, 3).join(" | ")})`);
      await context.close();
    }
  } finally {
    await browser.close();
    server.stop();
  }
  if (failures.length) {
    console.log(`\nFAILED (${failures.length})`);
    for (const f of failures) console.log(`  x  ${f}`);
    process.exit(1);
  }
  console.log("\nPASSED");
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
