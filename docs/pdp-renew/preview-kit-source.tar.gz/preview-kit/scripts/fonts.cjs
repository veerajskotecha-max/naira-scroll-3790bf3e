/*
  The fonts, bundled: every Google Fonts stylesheet the sources' index.html asks
  for (Cormorant Garamond and Jost today), latin and latin-ext only, as local
  woff2 with a stylesheet of relative URLs; and Velista from the shop's own
  public/fonts. Kept in cache/fonts; fetched again only when a source asks for
  a family or weight the cache has not seen.

    node scripts/fonts.cjs <source dir> [<source dir> ...]
*/
const { createHash } = require("node:crypto");
const { fs, path, CACHE, readJson, writeJson } = require("./lib.cjs");

const FONTS = path.join(CACHE, "fonts");
const SEEN = path.join(FONTS, "sources.json");
const UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36";

const get = async (url) => {
  for (let attempt = 0; ; attempt++) {
    try {
      const res = await fetch(url, { headers: { "user-agent": UA } });
      if (!res.ok) throw new Error(`${res.status} ${url}`);
      return Buffer.from(await res.arrayBuffer());
    } catch (e) {
      if (attempt >= 2) throw e;
    }
  }
};

const main = async () => {
  fs.mkdirSync(FONTS, { recursive: true });
  const sources = process.argv.slice(2);
  const sheets = new Set();
  for (const src of sources) {
    const html = fs.existsSync(path.join(src, "index.html")) ? fs.readFileSync(path.join(src, "index.html"), "utf8") : "";
    for (const m of html.matchAll(/href="(https:\/\/fonts\.googleapis\.com\/css2?\?[^"]+)"/g)) sheets.add(m[1].replace(/&amp;/g, "&"));
    for (const f of ["Velista.woff2", "Velista.ttf"]) {
      const own = path.join(src, "public/fonts", f);
      if (fs.existsSync(own)) fs.copyFileSync(own, path.join(FONTS, f));
    }
  }
  const seen = readJson(SEEN, []);
  const fresh = [...sheets].filter((s) => !seen.includes(s));
  if (!fresh.length && fs.existsSync(path.join(FONTS, "google.css"))) return void console.log(`fonts: ${fs.readdirSync(FONTS).filter((f) => f.endsWith(".woff2")).length} files held`);

  const faces = readJson(path.join(FONTS, "faces.json"), {});
  for (const sheet of fresh.length ? fresh : sheets) {
    const css = (await get(sheet)).toString("utf8");
    for (const m of css.matchAll(/\/\*\s*([a-z-]+)\s*\*\/\s*@font-face\s*{([^}]*)}/g)) {
      const [, subset, body] = m;
      if (subset !== "latin" && subset !== "latin-ext") continue;
      const family = /font-family:\s*'([^']+)'/.exec(body)?.[1];
      const style = /font-style:\s*(\w+)/.exec(body)?.[1] ?? "normal";
      const weight = /font-weight:\s*([\d ]+)/.exec(body)?.[1].trim() ?? "400";
      const src = /url\((https:[^)]+)\)\s*format\('(\w+)'\)/.exec(body);
      const range = /unicode-range:\s*([^;]+);/.exec(body)?.[1];
      if (!family || !src) continue;
      const bytes = await get(src[1]);
      const file = `${family.replace(/\s+/g, "")}-${subset}-${style}-${createHash("md5").update(bytes).digest("hex").slice(0, 10)}.woff2`;
      if (!fs.existsSync(path.join(FONTS, file))) fs.writeFileSync(path.join(FONTS, file), bytes);
      faces[`${family}|${style}|${weight}|${subset}`] = `@font-face{font-family:'${family}';font-style:${style};font-weight:${weight};font-display:swap;src:url(./${file}) format('woff2');${range ? `unicode-range:${range};` : ""}}`;
    }
    seen.push(sheet);
  }
  writeJson(path.join(FONTS, "faces.json"), faces);
  writeJson(SEEN, [...new Set(seen)]);
  fs.writeFileSync(path.join(FONTS, "google.css"), Object.values(faces).join("\n") + "\n");
  console.log(`fonts: ${Object.keys(faces).length} faces, ${fs.readdirSync(FONTS).filter((f) => f.endsWith(".woff2")).length} files held`);
};

main().catch((e) => {
  console.error(`fonts: ${e.message}`);
  process.exit(fs.existsSync(path.join(FONTS, "google.css")) ? 0 : 1);
});
