/* Shared by the kit's scripts: where things are, and the fixtures' naming. */
const fs = require("node:fs");
const path = require("node:path");
const { queryKey, cdnName, safeName, localName } = require("../guard/key.js");

const KIT = path.resolve(__dirname, "..");
const CACHE = path.join(KIT, "cache");
const WORK = path.join(KIT, ".work");
const DIST = process.env.PREVIEW_DIST ? path.resolve(process.env.PREVIEW_DIST) : path.join(KIT, "dist");
const BASE_SRC = process.env.PREVIEW_BEFORE_SRC || "/tmp/pdp-base";
const CONFIG = JSON.parse(fs.readFileSync(path.join(KIT, "products.json"), "utf8"));
const SIX = CONFIG.products.map((p) => p.handle);

const QUERIES_FILE = path.join(CACHE, "queries.json");
const MEDIA_DIR = path.join(CACHE, "media");
const THUMBS_DIR = path.join(CACHE, "thumbs");
const WANTED_FILE = path.join(CACHE, "wanted-media.json");

const readJson = (file, fallback) => {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    return fallback;
  }
};
const writeJson = (file, data) => {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(data, null, 1) + "\n");
};
const walk = (dir) =>
  fs.existsSync(dir) ? fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(path.join(dir, e.name)) : [path.join(dir, e.name)])) : [];

const CDN_ALL = /https:\/\/cdn\.shopify\.com\/[A-Za-z0-9_\-./%~+]+?\.(?:jpe?g|png|webp|gif|avif|heic)(?:\?[A-Za-z0-9_=&.%-]*)?/gi;

/** Every product node (it has a handle, a title and variants) inside a JSON value, the fullest copy of each. */
const productsIn = (value) => {
  const byHandle = new Map();
  const weigh = (n) => (n.variants?.edges?.length ?? n.variants?.nodes?.length ?? 0) + (n.images?.edges?.length ?? n.images?.nodes?.length ?? 0) + (n.description ? 1 : 0);
  const visit = (v) => {
    if (!v || typeof v !== "object") return;
    if (Array.isArray(v)) return void v.forEach(visit);
    if (typeof v.handle === "string" && typeof v.title === "string" && v.variants) {
      const have = byHandle.get(v.handle);
      if (!have || weigh(v) > weigh(have)) byHandle.set(v.handle, v);
    }
    for (const k of Object.keys(v)) visit(v[k]);
  };
  visit(value);
  return byHandle;
};

/** Every Shopify CDN address inside a JSON value or a text. */
const cdnUrlsIn = (value) => {
  const text = typeof value === "string" ? value : JSON.stringify(value);
  return [...new Set((text.match(CDN_ALL) || []).map((u) => u.replace(/\\u0026/g, "&")))];
};

const NOT_A_PHOTO = /size[-_ ]?guide|naira[-_ ]?packaging|gift\s*box|shipping\s*carton|catalog-square/i;
/** A product's photographs of the piece itself, in listing order (no feed square, gift box or size guide). */
const photosOf = (node) =>
  (node?.images?.edges ?? node?.images?.nodes?.map((n) => ({ node: n })) ?? [])
    .map((e) => e.node)
    .filter((i) => i?.url && !NOT_A_PHOTO.test(`${i.url} ${i.altText ?? ""}`));
const variantPhotosOf = (node) => (node?.variants?.edges ?? []).map((e) => e.node?.image?.url).filter(Boolean);

const mediaIndex = () => {
  const out = {};
  if (!fs.existsSync(MEDIA_DIR)) return out;
  for (const f of fs.readdirSync(MEDIA_DIR)) if (f.endsWith(".webp") && fs.statSync(path.join(MEDIA_DIR, f)).size > 0) out[f] = true;
  return out;
};

module.exports = { fs, path, KIT, CACHE, WORK, DIST, BASE_SRC, CONFIG, SIX, QUERIES_FILE, MEDIA_DIR, THUMBS_DIR, WANTED_FILE, photosOf, variantPhotosOf, safeName, readJson, writeJson, walk, CDN_ALL, productsIn, cdnUrlsIn, mediaIndex, queryKey, cdnName, localName };
