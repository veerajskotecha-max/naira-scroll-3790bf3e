/*
  The photographs the preview shows, fetched once from Shopify's public CDN
  (read-only GET) and kept in cache/media as WebP, at most products.json's
  imageWidth wide. A photograph is wanted when it is in the gallery of one of
  the six (or on one of their variants), or when a walk of the pages saw it
  (cache/wanted-media.json: the rails, the bag's add-ons, the menu).

    node scripts/media.cjs [<built js or dir to scan for names> ...]
*/
const { spawnSync } = require("node:child_process");
const { fs, path, CONFIG, SIX, QUERIES_FILE, MEDIA_DIR, THUMBS_DIR, WANTED_FILE, readJson, writeJson, walk, productsIn, cdnUrlsIn, cdnName, safeName, localName, photosOf, variantPhotosOf } = require("./lib.cjs");

const WIDTH = CONFIG.imageWidth || 900;
const QUALITY = CONFIG.imageQuality || 74;

const fetchBytes = async (url) => {
  for (let attempt = 0; ; attempt++) {
    try {
      const res = await fetch(url, { headers: { "user-agent": "preview-kit/1.0", accept: "image/jpeg,image/png,image/*;q=0.8" } });
      if (!res.ok) throw new Error(`${res.status} ${url}`);
      return Buffer.from(await res.arrayBuffer());
    } catch (e) {
      if (attempt >= 2) throw e;
      await new Promise((r) => setTimeout(r, 600 * (attempt + 1)));
    }
  }
};

const THUMB_WIDTH = CONFIG.thumbWidth || 220;
const THUMB_QUALITY = CONFIG.thumbQuality || 58;

const toWebp = (bytes, out, width = WIDTH, quality = QUALITY) => {
  const r = spawnSync("ffmpeg", ["-hide_banner", "-loglevel", "error", "-y", "-i", "-", "-frames:v", "1", "-vf", `scale='min(${width},iw)':-2`, "-c:v", "libwebp", "-quality", String(quality), "-compression_level", "6", out], { input: bytes, maxBuffer: 1 << 27 });
  if (r.status !== 0) {
    fs.rmSync(out, { force: true });
    throw new Error(`ffmpeg: ${String(r.stderr).slice(0, 200)}`);
  }
};

const main = async () => {
  fs.mkdirSync(MEDIA_DIR, { recursive: true });
  const cache = readJson(QUERIES_FILE, {});
  const responses = Object.values(cache).map((e) => e.response);

  // name -> address, from everything that names a photograph: the recorded answers, then the built code.
  const universe = new Map();
  const learn = (url) => {
    const cdn = cdnName(url);
    if (cdn === null) return;
    const name = safeName(cdn);
    if (!universe.has(name)) universe.set(name, url.split("?")[0] + (/[?&]v=\d+/.exec(url) ? `?${/[?&](v=\d+)/.exec(url)[1]}` : ""));
  };
  for (const url of cdnUrlsIn(responses)) learn(url);
  let code = "";
  for (const arg of process.argv.slice(2)) {
    const files = fs.existsSync(arg) && fs.statSync(arg).isDirectory() ? walk(arg).filter((f) => /\.(js|css|html)$/.test(f)) : [arg];
    for (const f of files) {
      if (!fs.existsSync(f)) continue;
      const text = fs.readFileSync(f, "utf8");
      if (f.endsWith(".js")) code += text;
      for (const url of cdnUrlsIn(text)) learn(url);
    }
  }

  /* Full photographs: every one in the galleries of the six, and every one a walk saw drawn large. */
  const wantedNames = new Set(Object.keys(readJson(WANTED_FILE, {})));
  const products = productsIn(responses);
  for (const handle of SIX) {
    const node = products.get(handle);
    if (!node) continue;
    for (const url of cdnUrlsIn(node)) wantedNames.add(safeName(cdnName(url)));
  }
  /* Small copies (inline, kit/thumbs.js): for every piece of the catalogue its first two photographs, each
     variant's own, and any photograph the shop's code names outright (the covers chosen by eye). A corner
     that shows any piece at all (the "just bought" card, search, the bag's suggestions) always has a picture. */
  const thumbNames = new Set();
  for (const node of products.values()) {
    for (const photo of photosOf(node).slice(0, 2)) thumbNames.add(safeName(cdnName(photo.url)));
    for (const url of variantPhotosOf(node)) thumbNames.add(safeName(cdnName(url)));
  }
  for (const name of universe.keys()) if (code.includes(`"${name}"`)) thumbNames.add(name);

  const jobs = [];
  const unknown = [];
  const plan = (names, dir, width, quality) => {
    for (const name of names) {
      if (!name) continue;
      const out = path.join(dir, `${name}.webp`);
      if (fs.existsSync(out) && fs.statSync(out).size > 0) continue;
      const url = universe.get(name);
      if (!url) unknown.push(name);
      else jobs.push({ name, url, out, width, quality });
    }
  };
  fs.mkdirSync(THUMBS_DIR, { recursive: true });
  plan(wantedNames, MEDIA_DIR, WIDTH, QUALITY);
  plan(thumbNames, THUMBS_DIR, THUMB_WIDTH, THUMB_QUALITY);
  writeJson(path.join(THUMBS_DIR, "..", "thumb-names.json"), [...thumbNames].sort());

  const failed = [];
  const queue = [...jobs];
  await Promise.all(
    Array.from({ length: 10 }, async () => {
      for (let job = queue.shift(); job; job = queue.shift()) {
        try {
          const u = new URL(job.url);
          u.searchParams.set("width", String(job.width));
          toWebp(await fetchBytes(u.toString()), job.out, job.width, job.quality);
        } catch (e) {
          failed.push(`${job.name}: ${e.message}`);
        }
      }
    }),
  );
  const held = fs.readdirSync(MEDIA_DIR).filter((f) => f.endsWith(".webp"));
  const bytes = held.reduce((n, f) => n + fs.statSync(path.join(MEDIA_DIR, f)).size, 0);
  const thumbBytes = [...thumbNames].reduce((n, name) => n + (fs.existsSync(path.join(THUMBS_DIR, `${name}.webp`)) ? fs.statSync(path.join(THUMBS_DIR, `${name}.webp`)).size : 0), 0);
  console.log(`media: ${wantedNames.size} photographs wanted in full, ${thumbNames.size} small copies (${(thumbBytes / 1e6).toFixed(1)} MB), ${jobs.length - failed.length} fetched now, ${held.length} full held (${(bytes / 1e6).toFixed(1)} MB)${failed.length ? `, ${failed.length} failed` : ""}${unknown.length ? `, ${unknown.length} with no known address` : ""}`);
  for (const f of failed.slice(0, 10)) console.warn(`  failed: ${f}`);
  for (const n of unknown.slice(0, 10)) console.warn(`  no address known for: ${n}`);
};

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
