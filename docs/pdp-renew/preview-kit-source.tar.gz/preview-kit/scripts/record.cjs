/*
  Records Storefront answers for the questions the preview's pages asked and the
  fixtures did not hold (the walk lists them). Read-only: a mutation is refused
  here, whatever asked for it; cart calls never reach this file (the guard
  answers them in the page).

    node scripts/record.cjs <misses.json>      [{ key, query, variables }]
    node scripts/record.cjs --refresh          ask every recorded question again
*/
const { fs, QUERIES_FILE, readJson, writeJson, queryKey } = require("./lib.cjs");

const ENDPOINT = "https://nc5eti-gp.myshopify.com/api/2025-07/graphql.json";
const TOKEN = "0f6fd83502924ac437a5d19180bb08c3"; // the shop's public Storefront token (src/lib/shopify.ts)

const ask = async (query, variables) => {
  const bare = query.replace(/#[^\n]*/g, "");
  if (/\bmutation\b/.test(bare) || /\bcart[A-Z]\w*\s*\(/.test(bare)) throw new Error("refused: the recorder only reads");
  for (let attempt = 0; ; attempt++) {
    try {
      const res = await fetch(ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-Shopify-Storefront-Access-Token": TOKEN },
        body: JSON.stringify({ query, variables }),
      });
      if (!res.ok) throw new Error(`Storefront answered ${res.status}`);
      const data = await res.json();
      if (data.errors?.length) throw new Error(data.errors.map((e) => e.message).join(", "));
      delete data.extensions;
      return data;
    } catch (e) {
      if (attempt >= 2) throw e;
      await new Promise((r) => setTimeout(r, 800 * (attempt + 1)));
    }
  }
};

const main = async () => {
  const cache = readJson(QUERIES_FILE, {});
  const refresh = process.argv.includes("--refresh");
  const file = process.argv.slice(2).find((a) => !a.startsWith("--"));
  const wanted = refresh ? Object.values(cache).map((e) => ({ query: e.query, variables: e.variables })) : readJson(file, []);
  let recorded = 0;
  const failed = [];
  for (const { query, variables } of wanted) {
    const key = queryKey(query, variables);
    if (cache[key] && !refresh) continue;
    try {
      const response = await ask(query, variables || {});
      cache[key] = { name: /(?:query|mutation)\s+(\w+)/.exec(query)?.[1] ?? "anonymous", variables: variables || {}, query, response, at: new Date().toISOString() };
      recorded += 1;
    } catch (e) {
      failed.push(`${/(?:query)\s+(\w+)/.exec(query)?.[1] ?? "query"} ${JSON.stringify(variables)}: ${e.message}`);
    }
  }
  writeJson(QUERIES_FILE, cache);
  console.log(`record: ${recorded} answers recorded, ${Object.keys(cache).length} held${failed.length ? `, ${failed.length} failed` : ""}`);
  for (const f of failed) console.warn(`  failed: ${f}`);
};

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
