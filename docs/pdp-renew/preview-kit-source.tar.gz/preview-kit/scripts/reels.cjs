/*
  The reels ("Shop the reel", and the film that is the gallery's last slide), bundled.

    node scripts/reels.cjs <source dir> [<source dir> ...] [--refresh]

  The shop reads its published reels from Supabase (table `reels` with their `reel_products`) and asks
  the `reel-media` function to sign the films' and posters' addresses. This script asks the same two
  questions once, exactly as a visitor's browser does (the publishable key from the source's .env, the
  key every visitor is sent), downloads the films and posters into cache/reels/, and writes
  cache/reels/reels.json. Read only: one GET on the table, the signing call, GETs of the files. Nothing
  is written to Supabase.

  A film is re-wrapped with its index first (ffmpeg -c copy -movflags +faststart: the same pictures,
  not re-encoded) so it starts from a plain static host; without ffmpeg it is bundled as it came.

  If the network or the key is missing, what cache/reels already holds is kept; with nothing held, the
  preview simply has no reels (the shop's own empty state: the section is not drawn).
*/
const { fs, path, CACHE, readJson, writeJson } = require("./lib.cjs");
const { execFileSync } = require("node:child_process");

const DIR = path.join(CACHE, "reels");
const FILE = path.join(DIR, "reels.json");
const SELECT = "id,title,caption,video_path,poster_path,sort_order,published,reel_products(id,handle,title,price_label,image_url,variant_id,position)";
const refresh = process.argv.includes("--refresh");
const sources = process.argv.slice(2).filter((a) => !a.startsWith("--"));

const envOf = (dir) => {
  for (const name of [".env", ".env.production", ".env.local"]) {
    const file = path.join(dir, name);
    if (!fs.existsSync(file)) continue;
    const env = {};
    for (const line of fs.readFileSync(file, "utf8").split("\n")) {
      const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/.exec(line);
      if (m) env[m[1]] = m[2].replace(/^["']|["']$/g, "");
    }
    if (env.VITE_SUPABASE_URL && env.VITE_SUPABASE_PUBLISHABLE_KEY) return env;
  }
  return null;
};
const fileName = (p, taken) => {
  let name = String(p).split("/").pop().replace(/[^A-Za-z0-9._-]/g, "-");
  while (taken.has(name)) name = "x-" + name;
  taken.add(name);
  return name;
};
const faststart = (file) => {
  if (!/\.(mp4|m4v|mov)$/i.test(file)) return;
  const tmp = file + ".fs.mp4";
  try {
    execFileSync("ffmpeg", ["-v", "error", "-y", "-i", file, "-c", "copy", "-movflags", "+faststart", tmp], { stdio: ["ignore", "ignore", "pipe"], timeout: 120000 });
    if (fs.existsSync(tmp) && fs.statSync(tmp).size > 1000) fs.renameSync(tmp, file);
  } catch {
    fs.rmSync(tmp, { force: true }); // no ffmpeg, or it would not take the file: bundled as it came
  }
};

const main = async () => {
  fs.mkdirSync(DIR, { recursive: true });
  const held = readJson(FILE, null);
  if (held && !refresh && Object.values(held.files || {}).every((f) => fs.existsSync(path.join(DIR, f)))) {
    return console.log(`reels: ${held.rows.length} held (${Object.keys(held.files).length} files); --refresh asks again`);
  }
  const env = sources.map(envOf).find(Boolean);
  if (!env) return console.log(`reels: no Supabase address in the sources' .env; ${held ? "kept what the cache holds" : "the preview has no reels"}`);
  const base = env.VITE_SUPABASE_URL.replace(/\/+$/, "");
  const headers = { apikey: env.VITE_SUPABASE_PUBLISHABLE_KEY, Authorization: `Bearer ${env.VITE_SUPABASE_PUBLISHABLE_KEY}` };
  const res = await fetch(`${base}/rest/v1/reels?select=${encodeURIComponent(SELECT)}&published=eq.true&order=sort_order.asc`, { headers });
  if (!res.ok) throw new Error(`the reels table answered ${res.status}`);
  const rows = await res.json();
  const sign = await fetch(`${base}/functions/v1/reel-media`, { method: "POST", headers: { ...headers, "Content-Type": "application/json" }, body: "{}" });
  if (!sign.ok) throw new Error(`reel-media answered ${sign.status}`);
  const urls = (await sign.json()).urls || {};
  const taken = new Set();
  const files = {};
  let bytes = 0;
  for (const row of rows) {
    for (const p of [row.video_path, row.poster_path].filter(Boolean)) {
      if (files[p] || !urls[p]) continue;
      const name = fileName(p, taken);
      const got = await fetch(urls[p]);
      if (!got.ok) {
        console.log(`reels: ${p} answered ${got.status}, left out`);
        continue;
      }
      const to = path.join(DIR, name);
      fs.writeFileSync(to, Buffer.from(await got.arrayBuffer()));
      faststart(to);
      bytes += fs.statSync(to).size;
      files[p] = name;
    }
  }
  writeJson(FILE, { fetchedAt: new Date().toISOString(), rows, files });
  console.log(`reels: ${rows.length} recorded, ${Object.keys(files).length} files fetched (${(bytes / 1e6).toFixed(1)} MB)`);
};

main().catch((e) => {
  console.log(`reels: could not be fetched (${e.message}); ${fs.existsSync(FILE) ? "kept what the cache holds" : "the preview has no reels"}`);
});
