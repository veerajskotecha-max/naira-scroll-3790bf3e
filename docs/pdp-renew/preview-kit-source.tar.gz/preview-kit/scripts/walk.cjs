/*
  Walks the built preview in a real browser, offline: dist/ is served by
  python3 -m http.server on 127.0.0.1:4410 and every request to any other host
  is aborted and counted. Used twice:

  - by build.sh, to learn what the pages still want (Storefront questions the
    fixtures do not hold, photographs not bundled yet): node scripts/walk.cjs --collect
  - by check.cjs, to prove the finished preview (see there).
*/
const { spawn } = require("node:child_process");
const net = require("node:net");
const { fs, path, DIST, WORK, SIX, WANTED_FILE, readJson, writeJson } = require("./lib.cjs");

const PORT = 4410;
const HOST = `127.0.0.1:${PORT}`;
const BASE = `http://${HOST}`;
const VIEWPORTS = {
  phone: { viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2 },
  small: { viewport: { width: 360, height: 640 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2 },
  laptop: { viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 },
};

const listening = () =>
  new Promise((resolve) => {
    const s = net.connect(PORT, "127.0.0.1");
    s.once("connect", () => (s.destroy(), resolve(true)));
    s.once("error", () => resolve(false));
  });

/** Serve dist on 127.0.0.1:4410 (the port must be free: a server on another folder would be walked instead). */
const serve = async () => {
  if (await listening()) {
    const marker = await fetch(`${BASE}/kit/fixtures.js`, { method: "HEAD" }).then((r) => r.headers.get("last-modified")).catch(() => null);
    const own = fs.existsSync(path.join(DIST, "kit/fixtures.js")) ? new Date(fs.statSync(path.join(DIST, "kit/fixtures.js")).mtime).toUTCString() : null;
    if (marker && own && marker === own) return { stop: () => {} };
    throw new Error(`port ${PORT} is taken by something that is not serving ${DIST}: stop it and run again`);
  }
  const child = spawn("python3", ["-m", "http.server", String(PORT), "--bind", "127.0.0.1"], { cwd: DIST, stdio: "ignore" });
  for (let i = 0; i < 50 && !(await listening()); i++) await new Promise((r) => setTimeout(r, 100));
  return { stop: () => child.kill() };
};

/** A page that cannot reach anything but the preview's own server, and says what tried. */
const guarded = async (browser, view, sink) => {
  const context = await browser.newContext(VIEWPORTS[view]);
  await context.route("**/*", (route) => {
    const url = route.request().url();
    let host = "";
    try {
      host = new URL(url).host;
    } catch {}
    if (/^(data|blob|about):/.test(url) || host === HOST) return route.continue();
    sink.outside.push(url);
    return route.abort();
  });
  const page = await context.newPage();
  page.on("console", (m) => {
    if (m.type() === "error") sink.errors.push(`console: ${m.text().slice(0, 240)}`);
  });
  page.on("pageerror", (e) => sink.errors.push(`page error: ${String(e).slice(0, 240)}`));
  page.on("response", (r) => {
    if (r.status() >= 400) sink.errors.push(`${r.status()} ${r.url().replace(BASE, "")}`);
  });
  return { context, page };
};

const settle = async (page, ms = 600) => {
  await page.waitForLoadState("networkidle").catch(() => {});
  await page.waitForTimeout(ms);
};

/** Scroll the whole page so every lazy section and photograph mounts, then come back up. */
const scrollThrough = async (page) => {
  for (let i = 0; i < 40; i++) {
    const done = await page.evaluate(() => {
      window.scrollBy(0, Math.round(window.innerHeight * 0.85));
      return window.scrollY + window.innerHeight >= document.documentElement.scrollHeight - 4;
    });
    await page.waitForTimeout(140);
    if (done) break;
  }
  await page.waitForTimeout(500);
  await page.evaluate(() => window.scrollTo(0, 0));
  await page.waitForTimeout(200);
};

const openPiece = async (page, build, handle, extra = "") => {
  await page.goto(`${BASE}/${build}/index.html?p=${encodeURIComponent(handle)}${extra}`);
  await page.waitForFunction(() => !!window.__nairaPreview && !!document.querySelector("#root h1"), null, { timeout: 30000 });
  await settle(page);
};

const harvest = (page) =>
  page.evaluate(() => (window.__nairaPreview.scan(), {
    misses: window.__nairaPreview.misses.map((m) => ({ key: m.key, query: m.query, variables: m.variables })),
    missingMedia: Object.assign({}, window.__nairaPreview.missingMedia),
    hits: Object.keys(window.__nairaPreview.hits || {}),
    log: window.__nairaPreview.log.slice(),
  }));

/** Open everything a shopper could: the page top to bottom, each option, the bag with two pieces, the menu and the search. */
const visit = async (browser, build, view, handle, sink) => {
  const { context, page } = await guarded(browser, view, sink);
  const take = async () => {
    const h = await harvest(page).catch(() => null);
    if (!h) return;
    for (const m of h.misses) sink.misses.set(m.key, m);
    for (const k of h.hits) sink.hits.add(k);
    Object.assign(sink.missingMedia, h.missingMedia);
  };
  try {
    await openPiece(page, build, handle);
    await scrollThrough(page);
    // every choice a piece offers (a colour or metal swaps the gallery)
    const radios = page.locator('main [role="radio"], #root [role="radiogroup"] [role="radio"]');
    const n = Math.min(await radios.count().catch(() => 0), 14);
    for (let i = 0; i < n; i++) {
      await radios.nth(i).click({ timeout: 800, force: true }).catch(() => {});
      await page.waitForTimeout(120);
    }
    await take();
    for (const label of ["Open menu", "Menu", "Search", "Open search"]) {
      const b = page.locator(`header button[aria-label^="${label}" i]`).first();
      if (await b.isVisible().catch(() => false)) {
        await b.click({ timeout: 800 }).catch(() => {});
        await page.waitForTimeout(500);
        await take();
        await page.keyboard.press("Escape").catch(() => {});
        await page.waitForTimeout(250);
      }
    }
    if (view === "laptop") {
      const links = page.locator("header nav a, header nav button");
      const count = Math.min(await links.count().catch(() => 0), 10);
      for (let i = 0; i < count; i++) {
        await links.nth(i).hover({ timeout: 500 }).catch(() => {});
        await page.waitForTimeout(160);
      }
      await take();
    }
    await openPiece(page, build, handle, "&bag=1");
    await page.waitForSelector('[role="dialog"][data-state="open"]', { timeout: 15000 }).catch(() => sink.errors.push(`the bag did not open on ${handle} (${build}, ${view})`));
    await page.waitForTimeout(900);
    const dialog = page.locator('[role="dialog"][data-state="open"]').first();
    await dialog.evaluate((el) => el.querySelectorAll("*").forEach((n) => n.scrollHeight > n.clientHeight + 20 && n.scrollTo(0, n.scrollHeight))).catch(() => {});
    await page.waitForTimeout(500);
    await take();
  } catch (e) {
    sink.errors.push(`walk of ${handle} (${build}, ${view}) stopped: ${String(e).slice(0, 200)}`);
    await take();
  } finally {
    await context.close();
  }
};

/* Pages walked side by side: one fewer than the machine's cores, at most four. */
const WORKERS = Math.max(1, Math.min(4, require("node:os").cpus().length - 1));
const pool = async (jobs, n) => {
  const queue = [...jobs];
  await Promise.all(Array.from({ length: n }, async () => { for (let job = queue.shift(); job; job = queue.shift()) await job(); }));
};

const collect = async ({ builds = ["before", "after"], views = ["phone", "laptop"] } = {}) => {
  const { chromium } = require("playwright");
  const server = await serve();
  const browser = await chromium.launch({ args: ["--disable-blink-features=AutomationControlled"] }) /* navigator.webdriver false: the shop holds back its later gallery photographs, reels and delivery dates from an automated browser, and the walk must see what a shopper sees */;
  const sink = { outside: [], errors: [], misses: new Map(), missingMedia: {}, hits: new Set() };
  try {
    const jobs = [];
    for (const build of builds) for (const view of views) for (const handle of SIX) jobs.push(() => visit(browser, build, view, handle, sink));
    await pool(jobs, WORKERS);
  } finally {
    await browser.close();
    server.stop();
  }
  return sink;
};

module.exports = { WORKERS, PORT, HOST, BASE, VIEWPORTS, serve, guarded, settle, scrollThrough, openPiece, harvest, collect, pool };

if (require.main === module) {
  (async () => {
    const same = readJson(path.join(WORK, "same.json"), { same: false }).same;
    const sink = await collect({ builds: same ? ["before"] : ["before", "after"] });
    const wanted = readJson(WANTED_FILE, {});
    let fresh = 0;
    for (const [name, url] of Object.entries(sink.missingMedia)) if (!(name in wanted)) (wanted[name] = url), (fresh += 1);
    writeJson(WANTED_FILE, wanted);
    const misses = [...sink.misses.values()];
    writeJson(path.join(WORK, "misses.json"), misses);
    // the recorded answers this walk actually used: assemble.cjs --prune ships only these
    writeJson(path.join(WORK, "used-queries.json"), [...sink.hits].sort());
    writeJson(path.join(WORK, "collect.json"), { misses: misses.length, missingMedia: Object.keys(sink.missingMedia).length, fresh, outside: [...new Set(sink.outside)], errors: [...new Set(sink.errors)] });
    console.log(`walk: ${misses.length} Storefront questions not in the fixtures, ${Object.keys(sink.missingMedia).length} photographs not bundled (${fresh} new), ${sink.outside.length} outside requests, ${new Set(sink.errors).size} errors`);
    for (const e of [...new Set(sink.errors)].slice(0, 12)) console.log(`  ${e}`);
  })().catch((e) => {
    console.error(e);
    process.exit(1);
  });
}
