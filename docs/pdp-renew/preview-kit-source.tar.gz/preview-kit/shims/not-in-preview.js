/*
  What the preview leaves out: every page but the product page (the hash router refuses their routes,
  so this never shows), and the lazily loaded parts listed under "absent" in products.json (the reels),
  which then simply are not there.
*/
export default function NotInPreview() {
  return null;
}
