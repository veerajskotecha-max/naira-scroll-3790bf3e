/*
  react-router-dom, as the preview needs it. The shop's App.tsx mounts a
  BrowserRouter; under a claude.ai page (or any file path) there is no server
  routing, and a pushState to /jewellery/<handle> would also move the base every
  relative URL resolves from. So BrowserRouter here is a hash router: the
  document stays <build>/index.html and the route lives after the #.

  It is also gated: a move to a route the preview does not carry (anything but
  the six product pages) is refused before it renders, and the guard says "Not
  in this preview". Checkout's own address (#/preview-checkout) is refused the
  same way, with the checkout note.
*/
import { createElement, useEffect } from "react";
import { unstable_HistoryRouter as HistoryRouter, UNSAFE_createHashHistory as createHashHistory, useLocation } from "react-router-dom";

export * from "react-router-dom";

const kit = () => (typeof window !== "undefined" && window.__nairaPreview) || null;
const pathOf = (to) => {
  if (typeof to === "string") {
    const s = to.replace(/^#/, "");
    return s.split(/[?#]/)[0] || "/";
  }
  return (to && to.pathname) || null;
};
const allowed = (to, from) => {
  const k = kit();
  const p = pathOf(to);
  if (!k || p === null) return true; // a search or hash change on the same page
  const abs = p.startsWith("/") ? p : (from || "/").replace(/[^/]*$/, "") + p;
  return k.allows(abs);
};

/* The shop's overlays (bag, menu, search, wishlist) close first and then call navigate() with the link's own
   href as the DOM has it (hooks/useBackToClose followOut). Under a hash router that attribute is
   "#/jewellery/x", which the router reads as a fragment of the page it is on: the address became
   "#/jewellery/a#/jewellery/x" and nothing moved. A fragment that starts "#/" is a route. */
const asRoute = (to) => {
  const hash = typeof to === "string" ? (to.charAt(0) === "#" ? to : "") : (to && to.hash) || "";
  return hash.indexOf("#/") === 0 ? hash.slice(1) : to;
};

let gated = null;
const history = () => {
  if (gated) return gated;
  // v5Compat: a push or replace tells the listener too (React Router's own BrowserRouter sets it); without it a
  // <Link> changed the address and left the old page on screen.
  const real = createHashHistory({ v5Compat: true });
  gated = {
    get action() {
      return real.action;
    },
    get location() {
      return real.location;
    },
    createHref: (to) => real.createHref(to),
    createURL: (to) => real.createURL(to),
    encodeLocation: (to) => real.encodeLocation(to),
    push(to, state) {
      to = asRoute(to);
      if (!allowed(to, real.location.pathname)) return void kit().refused(pathOf(to));
      real.push(to, state);
    },
    replace(to, state) {
      to = asRoute(to);
      if (!allowed(to, real.location.pathname)) return void kit().refused(pathOf(to));
      real.replace(to, state);
    },
    go: (n) => real.go(n),
    listen(fn) {
      return real.listen((update) => {
        const k = kit();
        if (k && !k.allows(update.location.pathname)) {
          // An address typed or assigned (checkout's): say so and step back off it.
          k.refused(update.location.pathname);
          real.go(-1);
          return;
        }
        fn(update);
      });
    },
  };
  return gated;
};

const Report = () => {
  const location = useLocation();
  useEffect(() => {
    const k = kit();
    if (k) k.route(location.pathname, location.search);
  }, [location.pathname, location.search]);
  return null;
};

export function BrowserRouter({ children }) {
  return createElement(HistoryRouter, { history: history() }, createElement(Report), children);
}
