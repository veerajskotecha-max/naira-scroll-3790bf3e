/*
  The preview kit's own Vite config. It lives outside both worktrees and is
  handed to the shop's own Vite with -c; nothing is written into the repos
  (cacheDir, envDir and outDir all point back here).

    cd <source> && PREVIEW_SRC=<source> PREVIEW_OUT=<dir> PREVIEW_NAME=before|after \
      node node_modules/vite/bin/vite.js build -c <kit>/vite.preview.config.mjs

  What it changes, against the shop's vite.config.ts:
  - base './' and one JS bundle (inlineDynamicImports), so the build runs under any path;
  - react-router-dom's BrowserRouter is the kit's hash router (shims/router.js): the
    document's address never changes, so every relative URL keeps working, and a
    route outside the preview is refused before it renders;
  - every page except the product page is a stub (keepPages in products.json), and so is every
    lazily loaded part listed under "absent" there (the reels);
  - no Supabase address or key, no .env, no public/ copy;
  - ASCII output (a claude.ai page refuses a file carrying U+FFFD);
  - index.html loses every remote tag and gains the fixtures and the guard, first.
*/
import { createRequire } from "node:module";
import path from "node:path";
import fs from "node:fs";
import { fileURLToPath } from "node:url";

const KIT = process.env.PREVIEW_KIT ? path.resolve(process.env.PREVIEW_KIT) : path.dirname(fileURLToPath(import.meta.url));
const SRC = path.resolve(process.env.PREVIEW_SRC || process.cwd());
const OUT = path.resolve(process.env.PREVIEW_OUT || path.join(KIT, ".work", "raw"));
const NAME = process.env.PREVIEW_NAME || "after";
const CONFIG = JSON.parse(fs.readFileSync(path.join(KIT, "products.json"), "utf8"));
const KEEP = new Set(CONFIG.keepPages || ["JewelDetailNext"]);
/* Lazily loaded parts the preview leaves out cleanly (the reels: their films live behind Supabase's signed links). */
const ABSENT = (CONFIG.absent || []).map((p) => path.join(SRC, p));

const req = createRequire(path.join(SRC, "package.json"));
const reactPlugin = req("@vitejs/plugin-react-swc");
const react = reactPlugin.default || reactPlugin;

process.env.VITE_SUPABASE_URL = "https://supabase.preview.invalid";
process.env.VITE_SUPABASE_PUBLISHABLE_KEY = "preview";
process.env.VITE_SUPABASE_PROJECT_ID = "preview";

const inKit = (id) => !!id && path.resolve(id.split("?")[0]).startsWith(path.join(KIT, "shims") + path.sep);
const ROUTER_SHIM = path.join(KIT, "shims/router.js");
const PAGE_STUB = path.join(KIT, "shims/not-in-preview.js");

/* The kit's shims live outside the source tree: their bare imports resolve as if written in src/. */
const kitResolve = () => ({
  name: "naira-preview-resolve",
  enforce: "pre",
  async resolveId(source, importer, options) {
    if (!importer) return null;
    if (source === "react-router-dom" && !inKit(importer)) return ROUTER_SHIM;
    if (inKit(importer) && !source.startsWith(".") && !path.isAbsolute(source)) {
      return this.resolve(source, path.join(SRC, "src/main.tsx"), { ...options, skipSelf: true });
    }
    return null;
  },
  /* Every lazily loaded page but the product page is a stub: the hash router refuses those routes anyway. */
  async resolveDynamicImport(specifier, importer) {
    if (typeof specifier !== "string" || !importer || inKit(importer)) return null;
    const r = await this.resolve(specifier, importer, { skipSelf: true });
    if (!r) return null;
    const file = r.id.split("?")[0];
    if (ABSENT.some((prefix) => file.startsWith(prefix))) return PAGE_STUB;
    const rel = path.relative(path.join(SRC, "src/pages"), file);
    if (rel.startsWith("..") || path.isAbsolute(rel)) return null;
    const base = path.basename(rel).replace(/\.[jt]sx?$/, "");
    return KEEP.has(base) ? null : PAGE_STUB;
  },
});

/* index.html: nothing remote, and the fixtures and the guard before anything else. */
const kitHtml = () => ({
  name: "naira-preview-html",
  enforce: "post",
  transformIndexHtml: {
    order: "post",
    handler(html) {
      let out = html
        .replace(/<noscript>[\s\S]*?<\/noscript>/gi, "")
        .replace(/<link\b[^>]*\bhref=["']https?:\/\/[^>]*>/gi, "")
        .replace(/<link\b[^>]*\bhref=["'][^"']*fonts\/[^"']*["'][^>]*>/gi, "")
        .replace(/<meta\b[^>]*google-site-verification[^>]*>/gi, "")
        .replace(/<script\b(?![^>]*\bsrc=)[^>]*>[\s\S]*?<\/script>/gi, (block) =>
          /connect\.facebook\.net|clarity\.ms|googletagmanager|google-analytics/.test(block) ? "" : block,
        )
        .replace(/<script\b[^>]*\bsrc=["']https?:\/\/[^>]*>\s*<\/script>/gi, "")
        .replace(/<!--[\s\S]*?-->/g, "");
      const head =
        `\n    <meta name="robots" content="noindex" />` +
        `\n    <script>window.__NAIRA_PREVIEW_BUILD__=${JSON.stringify(NAME)};</script>` +
        `\n    <link rel="stylesheet" href="../fonts/fonts.css" />` +
        `\n    <script src="../kit/fixtures.js"></script>` +
        `\n    <script src="../kit/thumbs.js"></script>` +
        `\n    <script src="../kit/guard.js"></script>`;
      out = out.replace(/<head>/i, `<head>${head}`);
      // The shop's hashed files sit in one folder both builds share (dist/assets).
      out = out.replace(/(["'(])\.\/assets\//g, "$1../assets/");
      return out;
    },
  },
  /* Velista is self-hosted at /fonts/ in the shop; in the preview the fonts folder is shared, one level above assets/. */
  generateBundle(_o, bundle) {
    for (const file of Object.values(bundle)) {
      if (file.type === "asset" && file.fileName.endsWith(".css")) {
        file.source = String(file.source).replace(/url\((["']?)(?:\.\.\/|\.\/|\/)fonts\//g, "url($1../fonts/");
      }
    }
  },
});

export default {
  root: SRC,
  base: "./",
  mode: "production",
  publicDir: false,
  envDir: path.join(KIT, "env-empty"),
  cacheDir: path.join(KIT, ".work", "vite-cache-" + NAME),
  logLevel: "warn",
  plugins: [kitResolve(), react(), kitHtml()],
  resolve: { alias: { "@": path.join(SRC, "src") } },
  esbuild: { charset: "ascii" },
  build: {
    outDir: OUT,
    emptyOutDir: true,
    target: "es2020",
    cssCodeSplit: false,
    manifest: false,
    chunkSizeWarningLimit: 20000,
    assetsInlineLimit: 8192,
    rollupOptions: {
      output: {
        inlineDynamicImports: true,
        entryFileNames: "assets/app-[hash].js",
        assetFileNames: "assets/[name]-[hash][extname]",
      },
    },
  },
};
